
GRANT EXECUTE ON [admin].[spCreateQueue] TO [cdp_Developer], [cdp_Developer], [cdp_UI]

