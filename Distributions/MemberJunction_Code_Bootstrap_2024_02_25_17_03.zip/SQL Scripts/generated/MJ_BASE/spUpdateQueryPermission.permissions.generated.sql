
GRANT EXECUTE ON [admin].[spUpdateQueryPermission] TO [cdp_Developer], [cdp_Integration]

