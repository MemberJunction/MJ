
GRANT EXECUTE ON [crm].[spCreateAccount] TO [cdp_Developer], [cdp_Integration]

