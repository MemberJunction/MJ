
GRANT EXECUTE ON [admin].[spCreateConversationDetail] TO [cdp_UI], [cdp_UI], [cdp_Developer], [cdp_Integration]

