
GRANT EXECUTE ON [crm].[spUpdateDealForecastCategory] TO [cdp_Developer], [cdp_Integration]

