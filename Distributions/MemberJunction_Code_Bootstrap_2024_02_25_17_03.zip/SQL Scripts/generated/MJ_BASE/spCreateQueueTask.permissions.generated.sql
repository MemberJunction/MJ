
GRANT EXECUTE ON [admin].[spCreateQueueTask] TO [cdp_Developer], [cdp_Developer], [cdp_UI]

