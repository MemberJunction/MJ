
GRANT EXECUTE ON [crm].[spUpdateDealType] TO [cdp_Developer], [cdp_Integration]

