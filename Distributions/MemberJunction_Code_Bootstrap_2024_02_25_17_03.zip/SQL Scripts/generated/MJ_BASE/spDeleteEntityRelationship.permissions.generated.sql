
GRANT EXECUTE ON [admin].[spDeleteEntityRelationship] TO [cdp_Developer], [cdp_Integration]

