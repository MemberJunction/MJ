
GRANT EXECUTE ON [dbo].[spCreateDemoKey] TO [cdp_Developer], [cdp_Integration]

