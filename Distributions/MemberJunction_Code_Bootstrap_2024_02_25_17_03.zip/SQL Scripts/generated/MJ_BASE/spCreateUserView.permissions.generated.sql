
GRANT EXECUTE ON [admin].[spCreateUserView] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

