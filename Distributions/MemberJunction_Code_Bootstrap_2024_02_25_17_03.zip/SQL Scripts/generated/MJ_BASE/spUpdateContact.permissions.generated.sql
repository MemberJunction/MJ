
GRANT EXECUTE ON [crm].[spUpdateContact] TO [cdp_Developer], [cdp_Integration]

