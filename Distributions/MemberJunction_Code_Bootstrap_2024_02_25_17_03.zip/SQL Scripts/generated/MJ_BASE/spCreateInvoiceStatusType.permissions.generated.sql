
GRANT EXECUTE ON [crm].[spCreateInvoiceStatusType] TO [cdp_Developer], [cdp_Integration]

