
GRANT EXECUTE ON [admin].[spDeleteUserView] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

