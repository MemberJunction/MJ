
GRANT EXECUTE ON [crm].[spCreateDealStage] TO [cdp_Developer], [cdp_Integration]

