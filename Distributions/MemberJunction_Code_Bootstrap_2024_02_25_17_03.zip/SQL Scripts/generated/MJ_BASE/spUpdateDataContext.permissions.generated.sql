
GRANT EXECUTE ON [admin].[spUpdateDataContext] TO [cdp_Developer], [cdp_Integration]

