
GRANT EXECUTE ON [crm].[spUpdateActivityAttachment] TO [cdp_Developer], [cdp_Integration]

