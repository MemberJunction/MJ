
GRANT EXECUTE ON [__mj].[spCreateRecordMergeLog] TO [cdp_Developer], [cdp_Integration]

