
GRANT EXECUTE ON [__mj].[spDeleteEntityField] TO [cdp_Developer], [cdp_Integration]

