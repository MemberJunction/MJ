
GRANT EXECUTE ON [__mj].[spDeleteListDetail] TO [cdp_Developer], [cdp_Integration]

