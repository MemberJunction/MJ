
GRANT EXECUTE ON [__mj].[spUpdateWorkspace] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

