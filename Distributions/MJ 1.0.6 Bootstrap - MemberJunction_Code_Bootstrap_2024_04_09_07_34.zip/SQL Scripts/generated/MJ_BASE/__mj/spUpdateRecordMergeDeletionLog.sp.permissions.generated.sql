
GRANT EXECUTE ON [__mj].[spUpdateRecordMergeDeletionLog] TO [cdp_Developer], [cdp_Integration]

