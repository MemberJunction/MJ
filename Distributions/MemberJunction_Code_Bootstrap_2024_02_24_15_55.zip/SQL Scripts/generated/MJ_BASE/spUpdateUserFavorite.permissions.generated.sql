
GRANT EXECUTE ON [admin].[spUpdateUserFavorite] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

