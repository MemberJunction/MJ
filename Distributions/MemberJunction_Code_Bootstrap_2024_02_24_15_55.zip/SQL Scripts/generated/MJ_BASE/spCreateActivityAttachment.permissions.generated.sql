
GRANT EXECUTE ON [crm].[spCreateActivityAttachment] TO [cdp_Developer], [cdp_Integration]

