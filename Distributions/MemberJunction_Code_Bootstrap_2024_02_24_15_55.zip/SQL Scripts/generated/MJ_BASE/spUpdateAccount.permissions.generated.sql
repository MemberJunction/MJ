
GRANT EXECUTE ON [crm].[spUpdateAccount] TO [cdp_Developer], [cdp_Integration]

