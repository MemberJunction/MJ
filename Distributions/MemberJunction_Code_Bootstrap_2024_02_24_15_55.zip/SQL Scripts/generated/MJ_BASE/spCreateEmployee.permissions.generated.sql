
GRANT EXECUTE ON [admin].[spCreateEmployee] TO [cdp_Developer], [cdp_Integration]

