
GRANT EXECUTE ON [admin].[spUpdateEntityDocumentType] TO [cdp_Developer], [cdp_Integration]

