
GRANT EXECUTE ON [admin].[spCreateUser] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

