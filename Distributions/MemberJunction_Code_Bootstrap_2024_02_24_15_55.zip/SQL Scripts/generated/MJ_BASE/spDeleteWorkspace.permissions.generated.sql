
GRANT EXECUTE ON [admin].[spDeleteWorkspace] TO [cdp_UI]

