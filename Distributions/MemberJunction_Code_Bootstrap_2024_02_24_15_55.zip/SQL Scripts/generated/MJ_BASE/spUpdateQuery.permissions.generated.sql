
GRANT EXECUTE ON [admin].[spUpdateQuery] TO [cdp_Developer], [cdp_Integration]

