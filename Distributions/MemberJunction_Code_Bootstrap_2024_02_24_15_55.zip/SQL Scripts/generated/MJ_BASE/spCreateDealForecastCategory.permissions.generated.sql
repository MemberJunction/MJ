
GRANT EXECUTE ON [crm].[spCreateDealForecastCategory] TO [cdp_Developer], [cdp_Integration]

