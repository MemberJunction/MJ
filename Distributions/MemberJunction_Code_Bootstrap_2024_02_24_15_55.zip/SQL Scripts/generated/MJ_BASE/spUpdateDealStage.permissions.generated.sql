
GRANT EXECUTE ON [crm].[spUpdateDealStage] TO [cdp_Developer], [cdp_Integration]

