
GRANT EXECUTE ON [admin].[spUpdateDashboardCategory] TO [cdp_Developer], [cdp_Integration]

