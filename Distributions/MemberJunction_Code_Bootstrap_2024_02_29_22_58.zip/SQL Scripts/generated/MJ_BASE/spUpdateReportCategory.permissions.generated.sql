
GRANT EXECUTE ON [admin].[spUpdateReportCategory] TO [cdp_Developer], [cdp_Integration]

