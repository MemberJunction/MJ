
GRANT EXECUTE ON [crm].[spCreateContact] TO [cdp_Developer], [cdp_Integration]

