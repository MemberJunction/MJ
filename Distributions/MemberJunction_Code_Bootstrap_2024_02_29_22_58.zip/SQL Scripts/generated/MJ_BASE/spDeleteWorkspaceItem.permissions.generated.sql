
GRANT EXECUTE ON [admin].[spDeleteWorkspaceItem] TO [cdp_UI]

