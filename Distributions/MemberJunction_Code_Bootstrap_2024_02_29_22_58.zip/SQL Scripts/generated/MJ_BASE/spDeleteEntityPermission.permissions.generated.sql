
GRANT EXECUTE ON [admin].[spDeleteEntityPermission] TO [cdp_Developer], [cdp_Integration]

