
GRANT EXECUTE ON [admin].[spCreateEntityDocumentType] TO [cdp_Developer], [cdp_Integration]

