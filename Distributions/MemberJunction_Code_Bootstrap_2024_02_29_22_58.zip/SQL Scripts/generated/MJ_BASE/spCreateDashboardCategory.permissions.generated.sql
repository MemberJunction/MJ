
GRANT EXECUTE ON [admin].[spCreateDashboardCategory] TO [cdp_Developer], [cdp_Integration]

