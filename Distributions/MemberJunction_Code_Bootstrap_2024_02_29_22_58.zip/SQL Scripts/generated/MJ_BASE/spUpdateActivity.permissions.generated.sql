
GRANT EXECUTE ON [crm].[spUpdateActivity] TO [cdp_Developer], [cdp_Integration]

