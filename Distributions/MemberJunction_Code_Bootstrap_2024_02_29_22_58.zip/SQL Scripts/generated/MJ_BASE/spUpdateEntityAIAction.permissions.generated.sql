
GRANT EXECUTE ON [admin].[spUpdateEntityAIAction] TO [cdp_Integration], [cdp_Developer]

