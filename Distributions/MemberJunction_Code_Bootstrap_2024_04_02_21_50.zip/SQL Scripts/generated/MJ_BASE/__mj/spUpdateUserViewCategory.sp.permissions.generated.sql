
GRANT EXECUTE ON [__mj].[spUpdateUserViewCategory] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

