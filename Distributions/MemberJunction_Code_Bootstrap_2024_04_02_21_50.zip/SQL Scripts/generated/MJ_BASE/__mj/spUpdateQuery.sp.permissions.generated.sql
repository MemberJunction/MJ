
GRANT EXECUTE ON [__mj].[spUpdateQuery] TO [cdp_Developer], [cdp_Integration]

