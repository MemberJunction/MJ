
GRANT EXECUTE ON [__mj].[spUpdateCompanyIntegrationRunAPILog] TO [cdp_Developer], [cdp_Integration]

