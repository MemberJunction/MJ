
GRANT EXECUTE ON [__mj].[spUpdateCompany] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

