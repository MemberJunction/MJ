
GRANT EXECUTE ON [__mj].[spDeleteUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]

