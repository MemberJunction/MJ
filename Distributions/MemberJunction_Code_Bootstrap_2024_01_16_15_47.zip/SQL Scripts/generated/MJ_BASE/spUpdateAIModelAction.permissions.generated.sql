
GRANT EXECUTE ON [admin].[spUpdateAIModelAction] TO [cdp_Integration], [cdp_Developer]

