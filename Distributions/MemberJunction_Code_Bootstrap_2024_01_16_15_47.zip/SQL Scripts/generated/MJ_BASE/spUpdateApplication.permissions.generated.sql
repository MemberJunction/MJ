
GRANT EXECUTE ON [admin].[spUpdateApplication] TO [cdp_Developer], [cdp_Integration]

