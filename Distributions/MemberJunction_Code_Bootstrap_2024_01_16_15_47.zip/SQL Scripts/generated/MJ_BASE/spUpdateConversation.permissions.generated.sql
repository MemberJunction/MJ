
GRANT EXECUTE ON [admin].[spUpdateConversation] TO [cdp_UI]

