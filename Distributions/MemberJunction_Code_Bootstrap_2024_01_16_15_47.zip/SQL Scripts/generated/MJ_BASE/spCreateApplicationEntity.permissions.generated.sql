
GRANT EXECUTE ON [admin].[spCreateApplicationEntity] TO [cdp_Developer], [cdp_Integration]

