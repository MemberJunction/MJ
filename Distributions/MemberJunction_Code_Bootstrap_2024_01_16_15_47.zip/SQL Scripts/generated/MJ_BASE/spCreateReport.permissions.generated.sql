
GRANT EXECUTE ON [admin].[spCreateReport] TO [cdp_UI]

