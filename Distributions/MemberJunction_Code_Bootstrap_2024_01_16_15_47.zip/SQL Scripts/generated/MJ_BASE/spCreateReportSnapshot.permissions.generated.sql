
GRANT EXECUTE ON [admin].[spCreateReportSnapshot] TO [cdp_UI]

