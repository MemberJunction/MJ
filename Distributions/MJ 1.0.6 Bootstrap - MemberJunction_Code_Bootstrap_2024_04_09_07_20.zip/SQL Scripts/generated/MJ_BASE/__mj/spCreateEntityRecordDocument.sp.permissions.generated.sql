
GRANT EXECUTE ON [__mj].[spCreateEntityRecordDocument] TO [cdp_Developer], [cdp_Integration]

