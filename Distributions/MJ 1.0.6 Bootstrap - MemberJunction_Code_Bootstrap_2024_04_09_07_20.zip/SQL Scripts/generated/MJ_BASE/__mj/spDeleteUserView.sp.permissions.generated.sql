
GRANT EXECUTE ON [__mj].[spDeleteUserView] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

