
GRANT EXECUTE ON [__mj].[spCreateCompanyIntegrationRecordMap] TO [cdp_Developer], [cdp_Integration]

