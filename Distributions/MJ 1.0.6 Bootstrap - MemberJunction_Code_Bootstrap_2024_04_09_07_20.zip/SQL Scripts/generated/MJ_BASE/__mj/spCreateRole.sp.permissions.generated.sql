
GRANT EXECUTE ON [__mj].[spCreateRole] TO [cdp_Developer], [cdp_Integration]

