
GRANT EXECUTE ON [__mj].[spDeleteWorkspaceItem] TO [cdp_UI]

