
GRANT EXECUTE ON [__mj].[spUpdateAIAction] TO [cdp_Integration], [cdp_Developer]

