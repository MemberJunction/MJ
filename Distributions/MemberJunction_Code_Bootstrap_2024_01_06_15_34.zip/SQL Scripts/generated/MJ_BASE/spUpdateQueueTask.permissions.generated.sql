
GRANT EXECUTE ON [admin].[spUpdateQueueTask] TO [cdp_Developer], [cdp_Developer]

