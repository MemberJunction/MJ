
GRANT EXECUTE ON [admin].[spUpdateEmployeeSkill] TO [cdp_Developer], [cdp_Integration]

