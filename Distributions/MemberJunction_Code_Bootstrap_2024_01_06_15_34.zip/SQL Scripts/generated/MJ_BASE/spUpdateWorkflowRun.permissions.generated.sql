
GRANT EXECUTE ON [admin].[spUpdateWorkflowRun] TO [cdp_Developer], [cdp_Integration]

