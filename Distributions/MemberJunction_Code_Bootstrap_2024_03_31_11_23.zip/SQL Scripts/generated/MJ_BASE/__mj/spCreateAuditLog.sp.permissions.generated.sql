
GRANT EXECUTE ON [__mj].[spCreateAuditLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

