
GRANT EXECUTE ON [__mj].[spCreateEntityDocumentType] TO [cdp_Developer], [cdp_Integration]

