
GRANT EXECUTE ON [__mj].[spUpdateCompanyIntegrationRecordMap] TO [cdp_Developer], [cdp_Integration]

