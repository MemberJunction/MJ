
GRANT EXECUTE ON [__mj].[spCreateQueue] TO [cdp_UI]

