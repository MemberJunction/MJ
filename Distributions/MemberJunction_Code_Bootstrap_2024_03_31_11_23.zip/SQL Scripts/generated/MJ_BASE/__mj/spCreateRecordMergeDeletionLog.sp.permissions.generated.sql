
GRANT EXECUTE ON [__mj].[spCreateRecordMergeDeletionLog] TO [cdp_Developer], [cdp_Integration]

