
GRANT EXECUTE ON [__mj].[spDeleteQueryCategory] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

