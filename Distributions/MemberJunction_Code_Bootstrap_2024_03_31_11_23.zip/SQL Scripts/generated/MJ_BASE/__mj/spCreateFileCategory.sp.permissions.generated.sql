
GRANT EXECUTE ON [__mj].[spCreateFileCategory] TO [cdp_Developer], [cdp_Integration]

