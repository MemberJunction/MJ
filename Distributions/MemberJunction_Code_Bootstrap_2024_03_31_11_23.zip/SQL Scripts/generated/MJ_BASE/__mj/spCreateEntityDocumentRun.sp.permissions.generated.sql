
GRANT EXECUTE ON [__mj].[spCreateEntityDocumentRun] TO [cdp_Developer], [cdp_Integration]

