
GRANT EXECUTE ON [__mj].[spCreateApplicationEntity] TO [cdp_Developer], [cdp_Integration]

