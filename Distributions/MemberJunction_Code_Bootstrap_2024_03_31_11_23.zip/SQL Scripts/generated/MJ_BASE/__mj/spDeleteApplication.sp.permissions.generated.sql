
GRANT EXECUTE ON [__mj].[spDeleteApplication] TO [cdp_Developer], [cdp_Integration]

