
GRANT EXECUTE ON [__mj].[spCreateQuery] TO [cdp_Developer], [cdp_Integration]

