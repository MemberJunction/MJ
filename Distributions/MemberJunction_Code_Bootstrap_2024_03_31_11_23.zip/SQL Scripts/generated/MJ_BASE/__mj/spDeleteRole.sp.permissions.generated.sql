
GRANT EXECUTE ON [__mj].[spDeleteRole] TO [cdp_Developer], [cdp_Integration]

