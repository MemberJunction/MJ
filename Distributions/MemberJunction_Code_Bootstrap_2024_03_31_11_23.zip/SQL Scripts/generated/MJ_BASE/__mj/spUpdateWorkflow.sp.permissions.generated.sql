
GRANT EXECUTE ON [__mj].[spUpdateWorkflow] TO [cdp_Developer], [cdp_Integration]

