
GRANT EXECUTE ON [__mj].[spUpdateEntityDocumentRun] TO [cdp_Developer], [cdp_Integration]

