
GRANT EXECUTE ON [__mj].[spCreateEntityField] TO [cdp_Developer], [cdp_Integration]

