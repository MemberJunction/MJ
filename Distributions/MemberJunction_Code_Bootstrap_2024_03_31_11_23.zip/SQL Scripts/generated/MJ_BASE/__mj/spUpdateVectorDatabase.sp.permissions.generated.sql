
GRANT EXECUTE ON [__mj].[spUpdateVectorDatabase] TO [cdp_Developer], [cdp_Integration]

