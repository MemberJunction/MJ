
GRANT EXECUTE ON [__mj].[spCreateReport] TO [cdp_UI]

