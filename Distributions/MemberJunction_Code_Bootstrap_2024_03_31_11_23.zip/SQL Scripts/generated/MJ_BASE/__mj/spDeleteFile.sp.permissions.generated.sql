
GRANT EXECUTE ON [__mj].[spDeleteFile] TO [cdp_Developer], [cdp_Integration]

