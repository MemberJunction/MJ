
GRANT EXECUTE ON [__mj].[spUpdateUserNotification] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

