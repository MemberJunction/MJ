
GRANT EXECUTE ON [__mj].[spCreateFileEntityRecordLink] TO [cdp_Developer], [cdp_Integration]

