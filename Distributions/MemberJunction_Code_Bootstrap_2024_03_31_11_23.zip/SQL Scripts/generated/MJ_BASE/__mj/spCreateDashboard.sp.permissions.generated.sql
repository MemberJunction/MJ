
GRANT EXECUTE ON [__mj].[spCreateDashboard] TO [cdp_UI]

