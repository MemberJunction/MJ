
GRANT EXECUTE ON [__mj].[spUpdateEntityRelationship] TO [cdp_Developer], [cdp_Integration]

