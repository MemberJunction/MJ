
GRANT EXECUTE ON [__mj].[spDeleteConversation] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

