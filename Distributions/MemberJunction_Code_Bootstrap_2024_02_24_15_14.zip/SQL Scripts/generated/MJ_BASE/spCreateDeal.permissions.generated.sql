
GRANT EXECUTE ON [crm].[spCreateDeal] TO [cdp_Developer], [cdp_Integration]

