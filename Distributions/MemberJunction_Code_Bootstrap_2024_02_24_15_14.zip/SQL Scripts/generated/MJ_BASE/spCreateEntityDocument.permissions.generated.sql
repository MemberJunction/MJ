
GRANT EXECUTE ON [admin].[spCreateEntityDocument] TO [cdp_Developer], [cdp_Integration]

