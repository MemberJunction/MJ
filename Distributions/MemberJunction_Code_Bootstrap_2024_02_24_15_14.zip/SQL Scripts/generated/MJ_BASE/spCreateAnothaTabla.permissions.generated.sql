
GRANT EXECUTE ON [dbo].[spCreateAnothaTabla] TO [cdp_Developer], [cdp_Integration]

