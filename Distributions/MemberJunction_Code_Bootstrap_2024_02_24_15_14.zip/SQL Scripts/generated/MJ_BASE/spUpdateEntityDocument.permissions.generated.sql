
GRANT EXECUTE ON [admin].[spUpdateEntityDocument] TO [cdp_Developer], [cdp_Integration]

