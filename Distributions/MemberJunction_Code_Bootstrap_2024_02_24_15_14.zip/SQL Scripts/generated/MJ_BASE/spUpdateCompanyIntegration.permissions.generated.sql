
GRANT EXECUTE ON [admin].[spUpdateCompanyIntegration] TO [cdp_Developer], [cdp_Integration]

