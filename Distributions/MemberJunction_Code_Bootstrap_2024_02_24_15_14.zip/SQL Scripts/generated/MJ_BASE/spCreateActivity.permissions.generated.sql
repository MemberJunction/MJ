
GRANT EXECUTE ON [crm].[spCreateActivity] TO [cdp_Developer], [cdp_Integration]

