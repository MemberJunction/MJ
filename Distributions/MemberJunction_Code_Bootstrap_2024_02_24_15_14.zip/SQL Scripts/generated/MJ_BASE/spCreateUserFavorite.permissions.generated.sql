
GRANT EXECUTE ON [admin].[spCreateUserFavorite] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

