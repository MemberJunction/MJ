
GRANT EXECUTE ON [crm].[spCreateDealType] TO [cdp_Developer], [cdp_Integration]

