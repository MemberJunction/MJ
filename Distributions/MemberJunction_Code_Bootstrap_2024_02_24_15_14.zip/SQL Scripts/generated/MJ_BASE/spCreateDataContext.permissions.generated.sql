
GRANT EXECUTE ON [admin].[spCreateDataContext] TO [cdp_Developer], [cdp_Integration]

