
GRANT EXECUTE ON [admin].[spCreateQueryField] TO [cdp_Developer], [cdp_Integration]

