
GRANT EXECUTE ON [admin].[spCreateReportCategory] TO [cdp_Developer], [cdp_Integration]

