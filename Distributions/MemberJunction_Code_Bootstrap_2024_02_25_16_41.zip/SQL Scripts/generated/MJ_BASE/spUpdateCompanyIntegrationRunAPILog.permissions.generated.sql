
GRANT EXECUTE ON [admin].[spUpdateCompanyIntegrationRunAPILog] TO [cdp_Developer], [cdp_Integration]

