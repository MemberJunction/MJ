
GRANT EXECUTE ON [admin].[spCreateVectorIndex] TO [cdp_Developer], [cdp_Integration]

