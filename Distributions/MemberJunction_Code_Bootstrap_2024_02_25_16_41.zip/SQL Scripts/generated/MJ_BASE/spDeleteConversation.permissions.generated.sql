
GRANT EXECUTE ON [admin].[spDeleteConversation] TO [cdp_UI]

