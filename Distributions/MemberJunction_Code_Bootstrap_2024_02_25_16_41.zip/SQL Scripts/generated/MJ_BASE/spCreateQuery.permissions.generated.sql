
GRANT EXECUTE ON [admin].[spCreateQuery] TO [cdp_Developer], [cdp_Integration]

