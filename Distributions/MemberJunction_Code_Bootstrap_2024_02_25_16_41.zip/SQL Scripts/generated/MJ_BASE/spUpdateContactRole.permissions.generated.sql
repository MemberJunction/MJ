
GRANT EXECUTE ON [reference].[spUpdateContactRole] TO [cdp_Developer], [cdp_Integration]

