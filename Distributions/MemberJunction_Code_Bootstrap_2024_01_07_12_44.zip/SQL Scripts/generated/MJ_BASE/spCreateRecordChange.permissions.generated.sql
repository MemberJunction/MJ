
GRANT EXECUTE ON [admin].[spCreateRecordChange] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

