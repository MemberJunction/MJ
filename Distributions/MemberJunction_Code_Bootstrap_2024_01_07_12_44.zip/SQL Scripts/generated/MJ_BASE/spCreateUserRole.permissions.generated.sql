
GRANT EXECUTE ON [admin].[spCreateUserRole] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

