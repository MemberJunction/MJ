
GRANT EXECUTE ON [admin].[spUpdateEmployeeCompanyIntegration] TO [cdp_Developer], [cdp_Integration]

