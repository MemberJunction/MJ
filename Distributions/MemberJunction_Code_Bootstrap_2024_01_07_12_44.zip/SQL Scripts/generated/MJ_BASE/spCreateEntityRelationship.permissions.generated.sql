
GRANT EXECUTE ON [admin].[spCreateEntityRelationship] TO [cdp_Developer], [cdp_Integration]

