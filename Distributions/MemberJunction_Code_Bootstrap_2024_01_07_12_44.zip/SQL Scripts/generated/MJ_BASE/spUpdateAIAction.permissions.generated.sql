
GRANT EXECUTE ON [admin].[spUpdateAIAction] TO [cdp_Integration], [cdp_Developer]

