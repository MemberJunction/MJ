
GRANT EXECUTE ON [admin].[spCreateUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]

