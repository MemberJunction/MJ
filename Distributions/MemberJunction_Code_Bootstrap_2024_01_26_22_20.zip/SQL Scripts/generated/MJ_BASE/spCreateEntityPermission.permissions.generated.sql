
GRANT EXECUTE ON [admin].[spCreateEntityPermission] TO [cdp_Developer], [cdp_Integration]

