
GRANT EXECUTE ON [admin].[spDeleteDashboard] TO [cdp_UI]

