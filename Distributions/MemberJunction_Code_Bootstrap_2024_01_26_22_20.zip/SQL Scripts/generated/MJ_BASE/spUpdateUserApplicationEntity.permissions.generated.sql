
GRANT EXECUTE ON [admin].[spUpdateUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]

