
GRANT EXECUTE ON [admin].[spDeleteList] TO [cdp_Developer], [cdp_Integration]

