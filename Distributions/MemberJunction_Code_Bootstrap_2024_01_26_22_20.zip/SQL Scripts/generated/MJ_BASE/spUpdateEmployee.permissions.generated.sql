
GRANT EXECUTE ON [admin].[spUpdateEmployee] TO [cdp_Developer], [cdp_Integration]

