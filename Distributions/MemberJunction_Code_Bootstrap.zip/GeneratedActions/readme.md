# mj_generatedactions

This library contains generated BaseAction sub-classes for each action defined in the MemberJunction framework outside of the core MJ framework. It is automatically maintained by the CodeGen tool. Look at the demo sub-folder of src for examples of how you can
further customize/sub-class generated BaseAction sub-classes with sub-sub-classes as needed.

# IMPORTANT
This library should only be imported on the server side. 