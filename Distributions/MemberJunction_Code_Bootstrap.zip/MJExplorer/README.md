# MemberJunction Explorer

This project is a basic user interface for MemberJunction environments.