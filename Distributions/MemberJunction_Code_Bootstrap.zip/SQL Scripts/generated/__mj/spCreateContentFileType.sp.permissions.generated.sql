
GRANT EXECUTE ON [__mj].[spCreateContentFileType] TO [cdp_Developer], [cdp_Integration]

