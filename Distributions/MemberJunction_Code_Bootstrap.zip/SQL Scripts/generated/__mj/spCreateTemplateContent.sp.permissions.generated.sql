
GRANT EXECUTE ON [__mj].[spCreateTemplateContent] TO [cdp_Integration], [cdp_Developer]

