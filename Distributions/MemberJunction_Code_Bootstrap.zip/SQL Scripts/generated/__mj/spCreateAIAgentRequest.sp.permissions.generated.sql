
GRANT EXECUTE ON [__mj].[spCreateAIAgentRequest] TO [cdp_Developer], [cdp_Integration]

