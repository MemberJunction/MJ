
GRANT EXECUTE ON [__mj].[spCreateEntityField] TO [cdp_Integration], [cdp_Developer]

