
GRANT EXECUTE ON [__mj].[spCreateCommunicationRun] TO [cdp_Developer], [cdp_Integration]

