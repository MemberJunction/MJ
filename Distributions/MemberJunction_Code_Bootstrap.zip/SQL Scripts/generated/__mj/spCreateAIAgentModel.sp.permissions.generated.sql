
GRANT EXECUTE ON [__mj].[spCreateAIAgentModel] TO [cdp_Developer], [cdp_Integration]

