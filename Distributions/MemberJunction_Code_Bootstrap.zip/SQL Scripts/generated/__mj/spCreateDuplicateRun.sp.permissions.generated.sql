
GRANT EXECUTE ON [__mj].[spCreateDuplicateRun] TO [cdp_Developer], [cdp_Integration]

