
GRANT EXECUTE ON [__mj].[spCreateQueryEntity] TO [cdp_Developer], [cdp_Integration]

