
GRANT EXECUTE ON [__mj].[spCreateAIAgentNote] TO [cdp_Developer], [cdp_Integration]

