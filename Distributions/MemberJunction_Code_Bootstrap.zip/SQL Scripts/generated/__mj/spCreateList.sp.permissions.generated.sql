
GRANT EXECUTE ON [__mj].[spCreateList] TO [cdp_Integration], [cdp_Developer]

