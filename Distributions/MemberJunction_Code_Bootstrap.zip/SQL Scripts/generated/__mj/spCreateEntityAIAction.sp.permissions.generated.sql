
GRANT EXECUTE ON [__mj].[spCreateEntityAIAction] TO [cdp_Integration], [cdp_Developer]

