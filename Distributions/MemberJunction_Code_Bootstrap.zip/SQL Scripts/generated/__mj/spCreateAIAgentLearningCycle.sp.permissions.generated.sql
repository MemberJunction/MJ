
GRANT EXECUTE ON [__mj].[spCreateAIAgentLearningCycle] TO [cdp_Developer], [cdp_Integration]

