
GRANT EXECUTE ON [__mj].[spCreateAIAgent] TO [cdp_Developer], [cdp_Integration]

