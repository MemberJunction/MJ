
GRANT EXECUTE ON [__mj].[spCreateRecordChangeReplayRun] TO [cdp_Integration], [cdp_Developer]

