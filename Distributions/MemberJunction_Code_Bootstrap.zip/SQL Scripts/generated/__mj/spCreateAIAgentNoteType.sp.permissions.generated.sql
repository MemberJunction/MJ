
GRANT EXECUTE ON [__mj].[spCreateAIAgentNoteType] TO [cdp_Developer], [cdp_Integration]

