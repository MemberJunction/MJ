
GRANT EXECUTE ON [__mj].[spCreateEntityDocumentSetting] TO [cdp_Developer], [cdp_Integration]

