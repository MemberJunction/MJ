
GRANT EXECUTE ON [__mj].[spCreateContentTypeAttribute] TO [cdp_Developer], [cdp_Integration]

