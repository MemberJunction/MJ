
GRANT EXECUTE ON [__mj].[spCreateActionContext] TO [cdp_Integration], [cdp_Developer]

