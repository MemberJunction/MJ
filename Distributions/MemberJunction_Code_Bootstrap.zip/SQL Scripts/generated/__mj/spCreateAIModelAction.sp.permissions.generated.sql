
GRANT EXECUTE ON [__mj].[spCreateAIModelAction] TO [cdp_Developer]

