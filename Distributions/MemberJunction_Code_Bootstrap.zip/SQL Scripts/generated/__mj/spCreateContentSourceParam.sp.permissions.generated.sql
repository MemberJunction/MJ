
GRANT EXECUTE ON [__mj].[spCreateContentSourceParam] TO [cdp_Developer], [cdp_Integration]

