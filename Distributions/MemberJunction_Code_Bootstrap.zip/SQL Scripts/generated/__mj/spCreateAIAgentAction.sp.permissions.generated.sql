
GRANT EXECUTE ON [__mj].[spCreateAIAgentAction] TO [cdp_Developer], [cdp_Integration]

