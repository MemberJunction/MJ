
GRANT EXECUTE ON [__mj].[spDeleteFileCategory] TO [cdp_UI], [cdp_Integration], [cdp_Developer]

