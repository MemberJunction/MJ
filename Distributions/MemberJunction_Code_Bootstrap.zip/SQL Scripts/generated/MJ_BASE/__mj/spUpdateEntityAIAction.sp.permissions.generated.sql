
GRANT EXECUTE ON [__mj].[spUpdateEntityAIAction] TO [cdp_Integration], [cdp_Developer]

