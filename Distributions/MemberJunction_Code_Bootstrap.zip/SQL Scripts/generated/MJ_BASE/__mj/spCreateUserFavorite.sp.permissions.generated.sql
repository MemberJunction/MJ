
GRANT EXECUTE ON [__mj].[spCreateUserFavorite] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

