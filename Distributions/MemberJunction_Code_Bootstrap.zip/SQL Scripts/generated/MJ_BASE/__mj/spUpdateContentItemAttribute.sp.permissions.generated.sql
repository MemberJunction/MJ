
GRANT EXECUTE ON [__mj].[spUpdateContentItemAttribute] TO [cdp_Developer], [cdp_Integration]

