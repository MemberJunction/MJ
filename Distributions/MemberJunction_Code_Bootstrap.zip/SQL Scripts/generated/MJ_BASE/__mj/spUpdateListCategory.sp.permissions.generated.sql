
GRANT EXECUTE ON [__mj].[spUpdateListCategory] TO [cdp_Developer], [cdp_Integration]

