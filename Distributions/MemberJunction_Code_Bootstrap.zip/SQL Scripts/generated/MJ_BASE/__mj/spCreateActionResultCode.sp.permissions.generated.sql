
GRANT EXECUTE ON [__mj].[spCreateActionResultCode] TO [cdp_Integration], [cdp_Developer]

