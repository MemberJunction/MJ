
GRANT EXECUTE ON [__mj].[spCreateUserViewRunDetail] TO [cdp_Developer], [cdp_Integration]

