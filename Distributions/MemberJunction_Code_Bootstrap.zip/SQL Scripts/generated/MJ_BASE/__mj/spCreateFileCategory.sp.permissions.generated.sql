
GRANT EXECUTE ON [__mj].[spCreateFileCategory] TO [cdp_Integration], [cdp_Developer]

