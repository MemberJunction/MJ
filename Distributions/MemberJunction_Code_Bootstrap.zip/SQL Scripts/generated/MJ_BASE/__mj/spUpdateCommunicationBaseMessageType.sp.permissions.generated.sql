
GRANT EXECUTE ON [__mj].[spUpdateCommunicationBaseMessageType] TO [cdp_Integration], [cdp_Developer]

