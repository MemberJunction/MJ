
GRANT EXECUTE ON [__mj].[spUpdateEntityBehaviorType] TO [cdp_Developer], [cdp_Integration]

