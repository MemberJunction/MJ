
GRANT EXECUTE ON [__mj].[spCreateAIModelType] TO [cdp_Integration], [cdp_Developer]

