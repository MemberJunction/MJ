
GRANT EXECUTE ON [__mj].[spUpdateEntityCommunicationField] TO [cdp_Developer], [cdp_Integration]

