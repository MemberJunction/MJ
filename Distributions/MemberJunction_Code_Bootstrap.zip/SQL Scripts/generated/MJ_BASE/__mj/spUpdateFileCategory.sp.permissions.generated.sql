
GRANT EXECUTE ON [__mj].[spUpdateFileCategory] TO [cdp_UI], [cdp_Integration], [cdp_Developer]

