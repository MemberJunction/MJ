
GRANT EXECUTE ON [__mj].[spCreateEntityCommunicationField] TO [cdp_Developer], [cdp_Integration]

