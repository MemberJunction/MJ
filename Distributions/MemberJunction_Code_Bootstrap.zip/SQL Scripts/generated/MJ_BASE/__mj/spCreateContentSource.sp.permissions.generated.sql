
GRANT EXECUTE ON [__mj].[spCreateContentSource] TO [cdp_Developer], [cdp_Integration]

