
GRANT EXECUTE ON [__mj].[spUpdateEntityField] TO [cdp_Integration], [cdp_Developer]

