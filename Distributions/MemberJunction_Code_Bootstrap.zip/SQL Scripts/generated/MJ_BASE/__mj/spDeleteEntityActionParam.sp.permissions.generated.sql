
GRANT EXECUTE ON [__mj].[spDeleteEntityActionParam] TO [cdp_Integration]

