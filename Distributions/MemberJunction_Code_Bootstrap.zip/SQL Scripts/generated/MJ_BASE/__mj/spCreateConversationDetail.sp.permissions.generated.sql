
GRANT EXECUTE ON [__mj].[spCreateConversationDetail] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

