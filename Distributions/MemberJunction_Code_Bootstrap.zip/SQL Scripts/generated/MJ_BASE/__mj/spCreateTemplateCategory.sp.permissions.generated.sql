
GRANT EXECUTE ON [__mj].[spCreateTemplateCategory] TO [cdp_Integration], [cdp_Developer]

