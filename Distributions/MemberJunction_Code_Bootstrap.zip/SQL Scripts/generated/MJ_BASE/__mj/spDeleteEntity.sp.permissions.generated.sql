
GRANT EXECUTE ON [__mj].[spDeleteEntity] TO [cdp_Developer], [cdp_Integration]

