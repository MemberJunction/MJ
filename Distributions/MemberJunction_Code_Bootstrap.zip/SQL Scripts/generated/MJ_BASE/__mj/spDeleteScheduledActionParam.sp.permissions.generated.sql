
GRANT EXECUTE ON [__mj].[spDeleteScheduledActionParam] TO [cdp_Integration]

