
GRANT EXECUTE ON [__mj].[spCreateActionAuthorization] TO [cdp_Integration], [cdp_Developer]

