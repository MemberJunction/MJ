
GRANT EXECUTE ON [__mj].[spDeleteEntityField] TO [cdp_Integration], [cdp_Developer]

