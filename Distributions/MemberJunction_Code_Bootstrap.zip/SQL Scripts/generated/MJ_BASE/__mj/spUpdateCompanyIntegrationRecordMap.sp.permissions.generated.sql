
GRANT EXECUTE ON [__mj].[spUpdateCompanyIntegrationRecordMap] TO [cdp_Integration], [cdp_Developer]

