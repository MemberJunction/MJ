
GRANT EXECUTE ON [__mj].[spUpdateAIModel] TO [cdp_Developer], [cdp_Integration]

