
GRANT EXECUTE ON [__mj].[spCreateRecordMergeLog] TO [cdp_Integration], [cdp_Developer]

