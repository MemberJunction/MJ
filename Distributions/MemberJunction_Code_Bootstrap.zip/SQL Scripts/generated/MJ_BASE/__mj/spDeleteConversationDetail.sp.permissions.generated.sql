
GRANT EXECUTE ON [__mj].[spDeleteConversationDetail] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

