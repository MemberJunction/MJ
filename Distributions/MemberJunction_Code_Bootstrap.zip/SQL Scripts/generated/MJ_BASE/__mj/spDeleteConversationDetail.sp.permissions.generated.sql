
GRANT EXECUTE ON [__mj].[spDeleteConversationDetail] TO [cdp_UI]

