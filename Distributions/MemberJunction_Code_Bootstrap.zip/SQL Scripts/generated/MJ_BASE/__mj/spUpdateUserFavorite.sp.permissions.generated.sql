
GRANT EXECUTE ON [__mj].[spUpdateUserFavorite] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

