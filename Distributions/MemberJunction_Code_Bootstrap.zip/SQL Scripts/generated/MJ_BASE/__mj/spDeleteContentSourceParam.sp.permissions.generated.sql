
GRANT EXECUTE ON [__mj].[spDeleteContentSourceParam] TO [cdp_Integration]

