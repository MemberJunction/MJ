
GRANT EXECUTE ON [__mj].[spUpdateUserApplication] TO [cdp_Integration], [cdp_Developer]

