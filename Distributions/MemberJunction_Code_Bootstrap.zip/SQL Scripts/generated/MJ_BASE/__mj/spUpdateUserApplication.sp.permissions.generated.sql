
GRANT EXECUTE ON [__mj].[spUpdateUserApplication] TO [cdp_Developer], [cdp_Integration]

