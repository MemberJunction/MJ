
GRANT EXECUTE ON [__mj].[spUpdateEntityDocument] TO [cdp_Integration], [cdp_Developer]

