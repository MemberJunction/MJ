
GRANT EXECUTE ON [__mj].[spUpdateListDetail] TO [cdp_Integration], [cdp_Developer]

