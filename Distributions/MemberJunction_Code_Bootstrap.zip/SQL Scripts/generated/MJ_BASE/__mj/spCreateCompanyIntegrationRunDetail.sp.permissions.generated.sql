
GRANT EXECUTE ON [__mj].[spCreateCompanyIntegrationRunDetail] TO [cdp_Developer], [cdp_Integration]

