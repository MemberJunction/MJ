
GRANT EXECUTE ON [__mj].[spCreateQueueTask] TO [cdp_UI]

