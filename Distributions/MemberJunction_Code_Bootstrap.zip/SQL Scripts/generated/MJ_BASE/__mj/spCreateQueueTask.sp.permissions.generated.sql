
GRANT EXECUTE ON [__mj].[spCreateQueueTask] TO [cdp_Developer], [cdp_Developer], [cdp_UI]

