
GRANT EXECUTE ON [__mj].[spDeleteActionResultCode] TO [cdp_Integration]

