
GRANT EXECUTE ON [__mj].[spDeleteContentItemAttribute] TO [cdp_Integration]

