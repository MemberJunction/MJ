
GRANT EXECUTE ON [__mj].[spUpdateEntityCommunicationMessageType] TO [cdp_Integration], [cdp_Developer]

