
GRANT EXECUTE ON [__mj].[spDeleteResourcePermission] TO [cdp_Integration]

