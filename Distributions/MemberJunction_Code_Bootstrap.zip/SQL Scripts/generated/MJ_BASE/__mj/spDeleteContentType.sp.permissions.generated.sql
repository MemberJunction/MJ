
GRANT EXECUTE ON [__mj].[spDeleteContentType] TO [cdp_Integration]

