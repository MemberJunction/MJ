
GRANT EXECUTE ON [__mj].[spUpdateContentProcessRun] TO [cdp_Developer], [cdp_Integration]

