
GRANT EXECUTE ON [__mj].[spUpdateCompanyIntegration] TO [cdp_Integration], [cdp_Developer]

