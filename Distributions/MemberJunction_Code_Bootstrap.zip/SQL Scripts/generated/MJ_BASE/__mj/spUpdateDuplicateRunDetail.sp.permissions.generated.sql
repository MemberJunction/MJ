
GRANT EXECUTE ON [__mj].[spUpdateDuplicateRunDetail] TO [cdp_Developer], [cdp_Integration]

