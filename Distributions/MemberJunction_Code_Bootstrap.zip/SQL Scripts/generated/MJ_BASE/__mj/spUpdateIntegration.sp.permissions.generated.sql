
GRANT EXECUTE ON [__mj].[spUpdateIntegration] TO [cdp_Developer], [cdp_Integration]

