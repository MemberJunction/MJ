
GRANT EXECUTE ON [__mj].[spDeleteTaggedItem] TO [cdp_UI]

