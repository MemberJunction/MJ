
GRANT EXECUTE ON [__mj].[spCreateQueue] TO [cdp_Developer], [cdp_Developer], [cdp_UI]

