
GRANT EXECUTE ON [__mj].[spUpdateConversation] TO [cdp_UI]

