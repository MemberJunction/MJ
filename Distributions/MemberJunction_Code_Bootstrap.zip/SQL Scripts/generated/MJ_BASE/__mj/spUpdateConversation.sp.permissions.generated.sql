
GRANT EXECUTE ON [__mj].[spUpdateConversation] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

