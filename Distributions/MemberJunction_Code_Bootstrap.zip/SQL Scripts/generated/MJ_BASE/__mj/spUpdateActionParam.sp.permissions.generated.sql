
GRANT EXECUTE ON [__mj].[spUpdateActionParam] TO [cdp_Integration], [cdp_Developer]

