
GRANT EXECUTE ON [__mj].[spUpdateRecordChangeReplayRun] TO [cdp_Integration], [cdp_Developer]

