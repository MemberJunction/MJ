
GRANT EXECUTE ON [__mj].[spCreateAIModel] TO [cdp_Developer], [cdp_Integration]

