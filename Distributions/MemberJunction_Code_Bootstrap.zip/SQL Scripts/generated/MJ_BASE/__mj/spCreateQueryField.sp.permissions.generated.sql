
GRANT EXECUTE ON [__mj].[spCreateQueryField] TO [cdp_Developer], [cdp_Integration]

