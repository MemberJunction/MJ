
GRANT EXECUTE ON [__mj].[spDeleteActionLibrary] TO [cdp_Integration]

