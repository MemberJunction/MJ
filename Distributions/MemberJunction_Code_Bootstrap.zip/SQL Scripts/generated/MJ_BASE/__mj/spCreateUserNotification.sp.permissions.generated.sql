
GRANT EXECUTE ON [__mj].[spCreateUserNotification] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

