
GRANT EXECUTE ON [__mj].[spDeleteScheduledAction] TO [cdp_Integration]

