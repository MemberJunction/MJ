
GRANT EXECUTE ON [__mj].[spDeleteEntityPermission] TO [cdp_Developer], [cdp_Integration]

