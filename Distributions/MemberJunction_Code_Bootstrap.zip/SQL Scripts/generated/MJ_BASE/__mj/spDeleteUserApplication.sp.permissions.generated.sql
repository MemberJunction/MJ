
GRANT EXECUTE ON [__mj].[spDeleteUserApplication] TO [cdp_Integration], [cdp_Developer]

