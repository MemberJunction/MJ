
GRANT EXECUTE ON [__mj].[spDeleteUserApplication] TO [cdp_Developer], [cdp_Integration]

