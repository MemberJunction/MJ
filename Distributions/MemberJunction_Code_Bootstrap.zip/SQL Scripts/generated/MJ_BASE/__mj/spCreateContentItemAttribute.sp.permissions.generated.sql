
GRANT EXECUTE ON [__mj].[spCreateContentItemAttribute] TO [cdp_Developer], [cdp_Integration]

