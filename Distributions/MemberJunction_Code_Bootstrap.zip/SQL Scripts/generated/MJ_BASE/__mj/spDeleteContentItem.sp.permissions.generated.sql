
GRANT EXECUTE ON [__mj].[spDeleteContentItem] TO [cdp_Integration]

