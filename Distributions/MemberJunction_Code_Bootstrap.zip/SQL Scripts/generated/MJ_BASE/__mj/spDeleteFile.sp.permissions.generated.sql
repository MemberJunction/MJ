
GRANT EXECUTE ON [__mj].[spDeleteFile] TO [cdp_Integration], [cdp_Developer]

