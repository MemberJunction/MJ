
GRANT EXECUTE ON [__mj].[spCreateContentType] TO [cdp_Developer], [cdp_Integration]

