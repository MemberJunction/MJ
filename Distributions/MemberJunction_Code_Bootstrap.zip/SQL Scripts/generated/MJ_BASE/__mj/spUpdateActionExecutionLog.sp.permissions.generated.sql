
GRANT EXECUTE ON [__mj].[spUpdateActionExecutionLog] TO [cdp_Integration], [cdp_Developer]

