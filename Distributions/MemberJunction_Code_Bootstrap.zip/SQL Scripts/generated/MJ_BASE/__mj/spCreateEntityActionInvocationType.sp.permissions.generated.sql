
GRANT EXECUTE ON [__mj].[spCreateEntityActionInvocationType] TO [cdp_Developer], [cdp_Integration]

