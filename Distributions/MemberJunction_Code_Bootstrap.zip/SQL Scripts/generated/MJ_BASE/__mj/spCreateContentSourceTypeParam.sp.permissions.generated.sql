
GRANT EXECUTE ON [__mj].[spCreateContentSourceTypeParam] TO [cdp_Developer], [cdp_Integration]

