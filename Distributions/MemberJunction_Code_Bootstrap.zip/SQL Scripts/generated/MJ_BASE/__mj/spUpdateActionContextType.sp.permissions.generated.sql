
GRANT EXECUTE ON [__mj].[spUpdateActionContextType] TO [cdp_Developer], [cdp_Integration]

