
GRANT EXECUTE ON [__mj].[spUpdateReport] TO [cdp_UI]

