
GRANT EXECUTE ON [__mj].[spCreateUserViewCategory] TO [cdp_Developer], [cdp_Integration]

