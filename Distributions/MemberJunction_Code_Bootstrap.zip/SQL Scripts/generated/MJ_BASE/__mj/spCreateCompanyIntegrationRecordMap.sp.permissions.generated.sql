
GRANT EXECUTE ON [__mj].[spCreateCompanyIntegrationRecordMap] TO [cdp_Integration], [cdp_Developer]

