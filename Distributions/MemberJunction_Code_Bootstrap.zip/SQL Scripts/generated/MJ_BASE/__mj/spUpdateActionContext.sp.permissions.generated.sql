
GRANT EXECUTE ON [__mj].[spUpdateActionContext] TO [cdp_Integration], [cdp_Developer]

