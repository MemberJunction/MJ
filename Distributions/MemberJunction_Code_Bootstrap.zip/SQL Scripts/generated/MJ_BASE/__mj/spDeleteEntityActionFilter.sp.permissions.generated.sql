
GRANT EXECUTE ON [__mj].[spDeleteEntityActionFilter] TO [cdp_Integration]

