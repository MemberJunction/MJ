
GRANT EXECUTE ON [__mj].[spDeleteAIModelAction] TO [cdp_Developer]

