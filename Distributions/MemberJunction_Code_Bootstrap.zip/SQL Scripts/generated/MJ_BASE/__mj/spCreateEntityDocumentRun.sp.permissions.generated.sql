
GRANT EXECUTE ON [__mj].[spCreateEntityDocumentRun] TO [cdp_Integration], [cdp_Developer]

