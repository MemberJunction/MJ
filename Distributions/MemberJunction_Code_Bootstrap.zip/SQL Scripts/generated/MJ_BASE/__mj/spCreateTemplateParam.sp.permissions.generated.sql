
GRANT EXECUTE ON [__mj].[spCreateTemplateParam] TO [cdp_Integration], [cdp_Developer]

