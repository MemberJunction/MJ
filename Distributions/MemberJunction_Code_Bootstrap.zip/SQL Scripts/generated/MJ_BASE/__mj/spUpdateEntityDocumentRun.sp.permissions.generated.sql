
GRANT EXECUTE ON [__mj].[spUpdateEntityDocumentRun] TO [cdp_Integration], [cdp_Developer]

