
GRANT EXECUTE ON [__mj].[spUpdateVersionInstallation] TO [cdp_Integration], [cdp_Developer]

