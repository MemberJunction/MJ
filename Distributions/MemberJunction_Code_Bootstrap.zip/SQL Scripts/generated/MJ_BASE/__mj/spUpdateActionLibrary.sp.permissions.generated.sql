
GRANT EXECUTE ON [__mj].[spUpdateActionLibrary] TO [cdp_Integration], [cdp_Developer]

