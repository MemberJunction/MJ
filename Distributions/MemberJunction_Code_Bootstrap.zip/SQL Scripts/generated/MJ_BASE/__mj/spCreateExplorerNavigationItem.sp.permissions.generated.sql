
GRANT EXECUTE ON [__mj].[spCreateExplorerNavigationItem] TO [cdp_Integration], [cdp_Developer]

