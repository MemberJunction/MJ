
GRANT EXECUTE ON [__mj].[spDeleteContentItemTag] TO [cdp_Integration]

