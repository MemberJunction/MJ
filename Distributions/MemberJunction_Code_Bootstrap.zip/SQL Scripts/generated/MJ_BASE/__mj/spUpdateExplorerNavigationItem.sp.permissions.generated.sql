
GRANT EXECUTE ON [__mj].[spUpdateExplorerNavigationItem] TO [cdp_Integration], [cdp_Developer]

