
GRANT EXECUTE ON [__mj].[spCreateCommunicationBaseMessageType] TO [cdp_Integration], [cdp_Developer]

