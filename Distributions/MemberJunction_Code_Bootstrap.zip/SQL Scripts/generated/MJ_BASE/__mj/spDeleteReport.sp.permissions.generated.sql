
GRANT EXECUTE ON [__mj].[spDeleteReport] TO [cdp_UI]

