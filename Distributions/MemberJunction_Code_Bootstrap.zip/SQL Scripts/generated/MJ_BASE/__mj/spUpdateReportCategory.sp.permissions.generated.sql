
GRANT EXECUTE ON [__mj].[spUpdateReportCategory] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

