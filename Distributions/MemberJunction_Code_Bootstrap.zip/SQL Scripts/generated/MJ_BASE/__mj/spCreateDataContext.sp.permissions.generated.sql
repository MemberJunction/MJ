
GRANT EXECUTE ON [__mj].[spCreateDataContext] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

