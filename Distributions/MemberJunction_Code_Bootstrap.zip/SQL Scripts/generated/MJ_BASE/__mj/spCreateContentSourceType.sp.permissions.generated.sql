
GRANT EXECUTE ON [__mj].[spCreateContentSourceType] TO [cdp_Developer], [cdp_Integration]

