
GRANT EXECUTE ON [__mj].[spUpdateAIAction] TO [cdp_Developer], [cdp_Integration]

