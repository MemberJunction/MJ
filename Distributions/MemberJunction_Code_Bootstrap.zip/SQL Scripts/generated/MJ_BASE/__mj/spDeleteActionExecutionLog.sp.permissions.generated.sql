
GRANT EXECUTE ON [__mj].[spDeleteActionExecutionLog] TO [cdp_Integration]

