
GRANT EXECUTE ON [__mj].[spCreateAction] TO [cdp_Integration], [cdp_Developer]

