
GRANT EXECUTE ON [__mj].[spUpdateCompanyIntegrationRun] TO [cdp_Developer], [cdp_Integration]

