
GRANT EXECUTE ON [__mj].[spCreateFileStorageProvider] TO [cdp_Integration], [cdp_Developer]

