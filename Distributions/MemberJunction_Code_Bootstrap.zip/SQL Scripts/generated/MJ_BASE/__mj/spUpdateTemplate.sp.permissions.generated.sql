
GRANT EXECUTE ON [__mj].[spUpdateTemplate] TO [cdp_Developer], [cdp_Integration]

