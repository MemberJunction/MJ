
GRANT EXECUTE ON [__mj].[spDeleteContentTypeAttribute] TO [cdp_Integration]

