
GRANT EXECUTE ON [__mj].[spUpdateTemplateCategory] TO [cdp_Integration], [cdp_Developer]

