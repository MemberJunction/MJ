
GRANT EXECUTE ON [__mj].[spCreateResourceLink] TO [cdp_Developer], [cdp_Integration]

