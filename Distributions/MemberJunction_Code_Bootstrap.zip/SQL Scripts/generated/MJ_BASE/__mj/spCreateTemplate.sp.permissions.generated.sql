
GRANT EXECUTE ON [__mj].[spCreateTemplate] TO [cdp_Developer], [cdp_Integration]

