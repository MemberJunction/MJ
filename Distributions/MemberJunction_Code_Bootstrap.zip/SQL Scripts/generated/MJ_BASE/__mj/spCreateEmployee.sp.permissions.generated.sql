
GRANT EXECUTE ON [__mj].[spCreateEmployee] TO [cdp_Developer], [cdp_Integration]

