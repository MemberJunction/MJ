
GRANT EXECUTE ON [__mj].[spDeleteContentSourceType] TO [cdp_Integration]

