
GRANT EXECUTE ON [__mj].[spDeleteCompany] TO [cdp_Integration], [cdp_Developer]

