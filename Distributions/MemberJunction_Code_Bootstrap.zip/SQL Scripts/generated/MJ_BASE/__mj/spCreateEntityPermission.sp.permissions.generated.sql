
GRANT EXECUTE ON [__mj].[spCreateEntityPermission] TO [cdp_Developer], [cdp_Integration]

