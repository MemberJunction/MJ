
GRANT EXECUTE ON [__mj].[spUpdateContentSourceParam] TO [cdp_Developer], [cdp_Integration]

