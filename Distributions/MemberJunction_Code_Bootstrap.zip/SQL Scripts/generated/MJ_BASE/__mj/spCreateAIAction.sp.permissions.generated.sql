
GRANT EXECUTE ON [__mj].[spCreateAIAction] TO [cdp_Developer]

