
GRANT EXECUTE ON [__mj].[spUpdateVectorIndex] TO [cdp_Integration], [cdp_Developer]

