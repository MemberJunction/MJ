
GRANT EXECUTE ON [__mj].[spUpdateDataContextItem] TO [cdp_UI], [cdp_Integration], [cdp_Developer]

