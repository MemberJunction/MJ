
GRANT EXECUTE ON [__mj].[spCreateLibraryItem] TO [cdp_Developer], [cdp_Integration]

