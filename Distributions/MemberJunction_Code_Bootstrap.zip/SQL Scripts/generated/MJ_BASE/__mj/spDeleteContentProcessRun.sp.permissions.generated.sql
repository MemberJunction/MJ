
GRANT EXECUTE ON [__mj].[spDeleteContentProcessRun] TO [cdp_Integration]

