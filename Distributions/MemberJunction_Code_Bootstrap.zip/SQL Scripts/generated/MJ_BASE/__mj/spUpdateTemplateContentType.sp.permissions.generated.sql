
GRANT EXECUTE ON [__mj].[spUpdateTemplateContentType] TO [cdp_Developer], [cdp_Integration]

