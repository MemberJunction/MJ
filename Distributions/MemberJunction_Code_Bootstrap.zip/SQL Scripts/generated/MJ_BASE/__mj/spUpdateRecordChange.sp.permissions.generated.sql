
GRANT EXECUTE ON [__mj].[spUpdateRecordChange] TO [cdp_Developer]

