
GRANT EXECUTE ON [__mj].[spUpdateAIModelAction] TO [cdp_Integration], [cdp_Developer]

