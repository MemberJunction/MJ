
GRANT EXECUTE ON [__mj].[spCreateRecordChange] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

