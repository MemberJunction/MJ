
GRANT EXECUTE ON [__mj].[spUpdateRecommendation] TO [cdp_Developer], [cdp_Integration]

