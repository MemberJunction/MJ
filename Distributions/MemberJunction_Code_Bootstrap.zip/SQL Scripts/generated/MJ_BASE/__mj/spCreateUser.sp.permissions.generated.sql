
GRANT EXECUTE ON [__mj].[spCreateUser] TO [cdp_Integration], [cdp_Developer]

