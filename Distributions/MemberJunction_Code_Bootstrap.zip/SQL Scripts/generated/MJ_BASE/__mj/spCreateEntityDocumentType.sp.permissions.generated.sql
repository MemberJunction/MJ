
GRANT EXECUTE ON [__mj].[spCreateEntityDocumentType] TO [cdp_Integration], [cdp_Developer]

