
GRANT EXECUTE ON [__mj].[spUpdateEntityRelationship] TO [cdp_Integration], [cdp_Developer]

