
GRANT EXECUTE ON [__mj].[spUpdateDuplicateRun] TO [cdp_Developer], [cdp_Integration]

