
GRANT EXECUTE ON [__mj].[spCreateVectorDatabase] TO [cdp_Integration], [cdp_Developer]

