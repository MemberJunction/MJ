
GRANT EXECUTE ON [__mj].[spCreateEntityDocument] TO [cdp_Integration], [cdp_Developer]

