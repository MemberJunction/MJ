
GRANT EXECUTE ON [__mj].[spUpdateEntityActionInvocation] TO [cdp_Integration], [cdp_Developer]

