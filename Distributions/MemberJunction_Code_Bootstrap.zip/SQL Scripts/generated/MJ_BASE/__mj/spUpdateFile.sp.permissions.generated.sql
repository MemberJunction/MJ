
GRANT EXECUTE ON [__mj].[spUpdateFile] TO [cdp_Developer], [cdp_Integration]

