
GRANT EXECUTE ON [__mj].[spUpdateFile] TO [cdp_Integration], [cdp_Developer]

