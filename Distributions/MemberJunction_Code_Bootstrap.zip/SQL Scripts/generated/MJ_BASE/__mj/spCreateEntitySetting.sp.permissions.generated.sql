
GRANT EXECUTE ON [__mj].[spCreateEntitySetting] TO [cdp_Integration], [cdp_Developer]

