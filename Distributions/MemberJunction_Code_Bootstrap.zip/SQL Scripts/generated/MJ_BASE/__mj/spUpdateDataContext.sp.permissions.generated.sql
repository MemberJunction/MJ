
GRANT EXECUTE ON [__mj].[spUpdateDataContext] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

