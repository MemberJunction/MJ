
GRANT EXECUTE ON [__mj].[spUpdateDataContext] TO [cdp_Developer], [cdp_Integration]

