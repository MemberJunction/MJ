
GRANT EXECUTE ON [__mj].[spDeleteDashboardCategory] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

