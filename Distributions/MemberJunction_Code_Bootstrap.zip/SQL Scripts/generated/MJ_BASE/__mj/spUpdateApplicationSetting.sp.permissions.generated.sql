
GRANT EXECUTE ON [__mj].[spUpdateApplicationSetting] TO [cdp_Integration], [cdp_Developer]

