
GRANT EXECUTE ON [__mj].[spUpdateActionAuthorization] TO [cdp_Integration], [cdp_Developer]

