
GRANT EXECUTE ON [__mj].[spUpdateActionFilter] TO [cdp_Integration], [cdp_Developer]

