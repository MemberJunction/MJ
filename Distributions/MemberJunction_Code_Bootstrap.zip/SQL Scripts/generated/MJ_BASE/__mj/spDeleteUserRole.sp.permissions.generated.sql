
GRANT EXECUTE ON [__mj].[spDeleteUserRole] TO [cdp_Developer], [cdp_Integration]

