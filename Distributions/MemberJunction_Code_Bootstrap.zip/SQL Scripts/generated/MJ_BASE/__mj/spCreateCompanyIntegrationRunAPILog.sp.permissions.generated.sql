
GRANT EXECUTE ON [__mj].[spCreateCompanyIntegrationRunAPILog] TO [cdp_Developer], [cdp_Integration]

