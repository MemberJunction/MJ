
GRANT EXECUTE ON [__mj].[spUpdateActionCategory] TO [cdp_Integration], [cdp_Developer]

