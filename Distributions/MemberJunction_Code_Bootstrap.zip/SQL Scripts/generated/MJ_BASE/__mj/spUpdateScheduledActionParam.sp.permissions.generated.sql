
GRANT EXECUTE ON [__mj].[spUpdateScheduledActionParam] TO [cdp_Developer], [cdp_Integration]

