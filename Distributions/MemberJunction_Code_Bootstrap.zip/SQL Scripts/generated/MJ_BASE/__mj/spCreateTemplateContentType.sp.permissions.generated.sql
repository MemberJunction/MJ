
GRANT EXECUTE ON [__mj].[spCreateTemplateContentType] TO [cdp_Developer], [cdp_Integration]

