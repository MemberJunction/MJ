
GRANT EXECUTE ON [__mj].[spCreateRecommendation] TO [cdp_Developer], [cdp_Integration]

