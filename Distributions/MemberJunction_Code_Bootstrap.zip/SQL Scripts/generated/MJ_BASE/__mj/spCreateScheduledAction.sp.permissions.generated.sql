
GRANT EXECUTE ON [__mj].[spCreateScheduledAction] TO [cdp_Integration], [cdp_Developer]

