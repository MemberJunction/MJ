
GRANT EXECUTE ON [__mj].[spCreateDataContextItem] TO [cdp_Developer], [cdp_Integration]

