
GRANT EXECUTE ON [__mj].[spUpdateContentItemTag] TO [cdp_Developer], [cdp_Integration]

