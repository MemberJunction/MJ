
GRANT EXECUTE ON [__mj].[spUpdateEmployee] TO [cdp_Developer], [cdp_Integration]

