
GRANT EXECUTE ON [__mj].[spCreateflyway_schema_history] TO [cdp_Developer], [cdp_Integration]

