
GRANT EXECUTE ON [__mj].[spCreateUserView] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

