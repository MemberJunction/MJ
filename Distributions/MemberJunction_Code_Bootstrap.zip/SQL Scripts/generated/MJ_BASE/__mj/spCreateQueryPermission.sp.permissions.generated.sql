
GRANT EXECUTE ON [__mj].[spCreateQueryPermission] TO [cdp_Developer], [cdp_Integration]

