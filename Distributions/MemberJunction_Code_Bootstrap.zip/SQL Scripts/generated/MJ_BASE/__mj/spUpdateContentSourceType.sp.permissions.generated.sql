
GRANT EXECUTE ON [__mj].[spUpdateContentSourceType] TO [cdp_Developer], [cdp_Integration]

