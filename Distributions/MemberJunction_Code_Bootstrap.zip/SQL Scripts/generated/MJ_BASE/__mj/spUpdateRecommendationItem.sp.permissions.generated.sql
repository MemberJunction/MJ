
GRANT EXECUTE ON [__mj].[spUpdateRecommendationItem] TO [cdp_Developer], [cdp_Integration]

