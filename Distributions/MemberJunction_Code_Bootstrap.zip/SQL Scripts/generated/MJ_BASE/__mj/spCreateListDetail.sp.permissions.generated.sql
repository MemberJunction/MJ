
GRANT EXECUTE ON [__mj].[spCreateListDetail] TO [cdp_Integration], [cdp_Developer]

