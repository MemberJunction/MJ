
GRANT EXECUTE ON [__mj].[spUpdateAction] TO [cdp_Integration], [cdp_Developer]

