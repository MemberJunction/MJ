
GRANT EXECUTE ON [__mj].[spCreateEntityCommunicationMessageType] TO [cdp_Integration], [cdp_Developer]

