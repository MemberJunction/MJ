
GRANT EXECUTE ON [__mj].[spCreateUserApplication] TO [cdp_Integration], [cdp_Developer]

