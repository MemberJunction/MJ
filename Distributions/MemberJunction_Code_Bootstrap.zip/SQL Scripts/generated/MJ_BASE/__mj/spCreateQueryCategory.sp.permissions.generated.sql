
GRANT EXECUTE ON [__mj].[spCreateQueryCategory] TO [cdp_Integration], [cdp_Developer]

