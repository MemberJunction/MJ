
GRANT EXECUTE ON [__mj].[spUpdateDashboardCategory] TO [cdp_Developer], [cdp_Integration]

