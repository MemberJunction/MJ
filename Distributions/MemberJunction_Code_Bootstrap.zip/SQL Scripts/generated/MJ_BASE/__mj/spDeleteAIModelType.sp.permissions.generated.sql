
GRANT EXECUTE ON [__mj].[spDeleteAIModelType] TO [cdp_Developer]

