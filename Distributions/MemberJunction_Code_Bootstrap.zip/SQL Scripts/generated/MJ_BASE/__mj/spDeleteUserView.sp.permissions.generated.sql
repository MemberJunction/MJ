
GRANT EXECUTE ON [__mj].[spDeleteUserView] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

