
GRANT EXECUTE ON [__mj].[spCreateLibrary] TO [cdp_Integration], [cdp_Developer]

