
GRANT EXECUTE ON [__mj].[spUpdateCommunicationLog] TO [cdp_Developer], [cdp_Integration]

