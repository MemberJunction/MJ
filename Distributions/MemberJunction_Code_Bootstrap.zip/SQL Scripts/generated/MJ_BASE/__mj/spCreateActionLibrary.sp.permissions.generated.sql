
GRANT EXECUTE ON [__mj].[spCreateActionLibrary] TO [cdp_Integration], [cdp_Developer]

