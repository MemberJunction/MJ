
GRANT EXECUTE ON [__mj].[spUpdateContentSourceTypeParam] TO [cdp_Developer], [cdp_Integration]

