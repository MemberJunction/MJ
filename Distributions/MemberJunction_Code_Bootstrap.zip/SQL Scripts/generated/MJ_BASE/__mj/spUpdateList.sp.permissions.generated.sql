
GRANT EXECUTE ON [__mj].[spUpdateList] TO [cdp_Integration], [cdp_Developer]

