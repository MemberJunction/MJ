
GRANT EXECUTE ON [__mj].[spCreateScheduledActionParam] TO [cdp_Developer], [cdp_Integration]

