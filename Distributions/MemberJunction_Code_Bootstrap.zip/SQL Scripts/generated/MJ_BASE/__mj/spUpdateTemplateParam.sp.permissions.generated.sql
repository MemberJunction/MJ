
GRANT EXECUTE ON [__mj].[spUpdateTemplateParam] TO [cdp_Integration], [cdp_Developer]

