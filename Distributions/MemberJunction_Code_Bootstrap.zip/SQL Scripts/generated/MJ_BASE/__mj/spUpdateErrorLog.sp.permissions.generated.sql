
GRANT EXECUTE ON [__mj].[spUpdateErrorLog] TO [cdp_Integration], [cdp_Developer]

