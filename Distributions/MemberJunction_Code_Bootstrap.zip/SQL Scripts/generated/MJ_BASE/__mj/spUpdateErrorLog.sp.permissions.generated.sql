
GRANT EXECUTE ON [__mj].[spUpdateErrorLog] TO [cdp_Developer], [cdp_Integration]

