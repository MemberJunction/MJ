
GRANT EXECUTE ON [__mj].[spDeleteActionCategory] TO [cdp_Integration]

