
GRANT EXECUTE ON [__mj].[spUpdateScheduledAction] TO [cdp_Integration], [cdp_Developer]

