
GRANT EXECUTE ON [__mj].[spCreateCommunicationProviderMessageType] TO [cdp_Integration], [cdp_Developer]

