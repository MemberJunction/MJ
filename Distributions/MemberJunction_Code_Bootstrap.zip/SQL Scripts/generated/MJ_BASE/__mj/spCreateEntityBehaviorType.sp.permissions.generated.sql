
GRANT EXECUTE ON [__mj].[spCreateEntityBehaviorType] TO [cdp_Developer], [cdp_Integration]

