
GRANT EXECUTE ON [__mj].[spDeleteActionFilter] TO [cdp_Integration]

