
GRANT EXECUTE ON [__mj].[spUpdateLibrary] TO [cdp_Integration], [cdp_Developer]

