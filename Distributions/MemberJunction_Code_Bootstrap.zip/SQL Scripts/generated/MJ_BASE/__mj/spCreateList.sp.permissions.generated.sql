
GRANT EXECUTE ON [__mj].[spCreateList] TO [cdp_Developer], [cdp_Integration]

