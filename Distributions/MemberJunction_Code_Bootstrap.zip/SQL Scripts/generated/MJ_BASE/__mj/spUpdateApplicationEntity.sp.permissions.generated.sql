
GRANT EXECUTE ON [__mj].[spUpdateApplicationEntity] TO [cdp_Developer], [cdp_Integration]

