
GRANT EXECUTE ON [__mj].[spUpdateEntityDocumentType] TO [cdp_Developer], [cdp_Integration]

