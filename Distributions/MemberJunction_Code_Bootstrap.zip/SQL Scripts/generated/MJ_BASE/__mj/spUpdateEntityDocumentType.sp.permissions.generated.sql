
GRANT EXECUTE ON [__mj].[spUpdateEntityDocumentType] TO [cdp_Integration], [cdp_Developer]

