
GRANT EXECUTE ON [__mj].[spUpdateContentItem] TO [cdp_Developer], [cdp_Integration]

