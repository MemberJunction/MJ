
GRANT EXECUTE ON [__mj].[spUpdateCompany] TO [cdp_UI], [cdp_Integration], [cdp_Developer]

