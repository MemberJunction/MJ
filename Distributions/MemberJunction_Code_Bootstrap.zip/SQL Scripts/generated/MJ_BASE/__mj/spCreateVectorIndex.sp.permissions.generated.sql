
GRANT EXECUTE ON [__mj].[spCreateVectorIndex] TO [cdp_Integration], [cdp_Developer]

