
GRANT EXECUTE ON [__mj].[spCreateListCategory] TO [cdp_Developer], [cdp_Integration]

