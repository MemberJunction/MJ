
GRANT EXECUTE ON [__mj].[spUpdateCommunicationProvider] TO [cdp_Integration], [cdp_Developer]

