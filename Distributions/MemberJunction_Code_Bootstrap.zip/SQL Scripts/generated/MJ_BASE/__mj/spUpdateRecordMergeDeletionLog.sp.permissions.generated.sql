
GRANT EXECUTE ON [__mj].[spUpdateRecordMergeDeletionLog] TO [cdp_Integration], [cdp_Developer]

