
GRANT EXECUTE ON [__mj].[spUpdateEntityBehavior] TO [cdp_Developer], [cdp_Integration]

