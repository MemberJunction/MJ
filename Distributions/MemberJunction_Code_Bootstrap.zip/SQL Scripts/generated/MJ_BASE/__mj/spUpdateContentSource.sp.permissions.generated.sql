
GRANT EXECUTE ON [__mj].[spUpdateContentSource] TO [cdp_Developer], [cdp_Integration]

