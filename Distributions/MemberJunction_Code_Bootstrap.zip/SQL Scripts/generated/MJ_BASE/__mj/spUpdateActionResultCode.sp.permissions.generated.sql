
GRANT EXECUTE ON [__mj].[spUpdateActionResultCode] TO [cdp_Integration], [cdp_Developer]

