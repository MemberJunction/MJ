
GRANT EXECUTE ON [__mj].[spDeleteUser] TO [cdp_Integration], [cdp_Developer]

