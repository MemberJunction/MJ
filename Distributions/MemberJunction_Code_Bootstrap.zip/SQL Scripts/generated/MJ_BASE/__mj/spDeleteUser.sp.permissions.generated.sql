
GRANT EXECUTE ON [__mj].[spDeleteUser] TO [cdp_Developer], [cdp_Integration]

