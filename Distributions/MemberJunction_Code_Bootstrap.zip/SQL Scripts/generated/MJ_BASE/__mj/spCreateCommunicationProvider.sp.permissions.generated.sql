
GRANT EXECUTE ON [__mj].[spCreateCommunicationProvider] TO [cdp_Integration], [cdp_Developer]

