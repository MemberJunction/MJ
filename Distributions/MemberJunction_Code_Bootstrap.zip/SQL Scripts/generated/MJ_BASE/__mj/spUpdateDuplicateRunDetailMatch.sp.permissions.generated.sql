
GRANT EXECUTE ON [__mj].[spUpdateDuplicateRunDetailMatch] TO [cdp_Integration], [cdp_Developer]

