
GRANT EXECUTE ON [__mj].[spCreateUserRole] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

