
GRANT EXECUTE ON [__mj].[spUpdateEntityActionFilter] TO [cdp_Integration], [cdp_Developer]

