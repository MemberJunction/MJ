
GRANT EXECUTE ON [__mj].[spCreateReportCategory] TO [cdp_Integration], [cdp_Developer]

