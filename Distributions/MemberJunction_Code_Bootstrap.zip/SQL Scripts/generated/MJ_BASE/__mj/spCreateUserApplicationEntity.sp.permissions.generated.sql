
GRANT EXECUTE ON [__mj].[spCreateUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]

