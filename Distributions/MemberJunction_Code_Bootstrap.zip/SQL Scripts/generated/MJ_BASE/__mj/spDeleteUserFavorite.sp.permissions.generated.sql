
GRANT EXECUTE ON [__mj].[spDeleteUserFavorite] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

