
GRANT EXECUTE ON [__mj].[spUpdateEntityActionParam] TO [cdp_Developer], [cdp_Integration]

