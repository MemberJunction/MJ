
GRANT EXECUTE ON [__mj].[spCreateRecommendationItem] TO [cdp_Developer], [cdp_Integration]

