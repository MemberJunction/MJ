
GRANT EXECUTE ON [__mj].[spUpdateWorkspace] TO [cdp_UI]

