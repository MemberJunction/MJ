
GRANT EXECUTE ON [__mj].[spCreateFile] TO [cdp_Integration], [cdp_Developer]

