
GRANT EXECUTE ON [__mj].[spUpdateUser] TO [cdp_Integration], [cdp_Developer]

