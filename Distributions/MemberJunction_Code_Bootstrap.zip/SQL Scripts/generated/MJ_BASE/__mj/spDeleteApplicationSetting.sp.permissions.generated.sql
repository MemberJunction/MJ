
GRANT EXECUTE ON [__mj].[spDeleteApplicationSetting] TO [cdp_Integration]

