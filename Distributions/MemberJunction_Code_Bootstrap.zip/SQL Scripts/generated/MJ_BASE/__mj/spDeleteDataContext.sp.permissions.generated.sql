
GRANT EXECUTE ON [__mj].[spDeleteDataContext] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

