
GRANT EXECUTE ON [__mj].[spUpdateEmployeeRole] TO [cdp_Integration], [cdp_Developer]

