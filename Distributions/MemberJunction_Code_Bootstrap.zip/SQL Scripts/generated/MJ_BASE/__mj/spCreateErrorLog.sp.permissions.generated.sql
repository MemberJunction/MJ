
GRANT EXECUTE ON [__mj].[spCreateErrorLog] TO [cdp_Integration], [cdp_Developer]

