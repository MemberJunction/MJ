
GRANT EXECUTE ON [__mj].[spUpdateAuditLog] TO [cdp_Developer]

