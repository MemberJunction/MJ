
GRANT EXECUTE ON [__mj].[spUpdateEntityDocumentSetting] TO [cdp_Developer], [cdp_Integration]

