
GRANT EXECUTE ON [__mj].[spUpdateCommunicationRun] TO [cdp_Developer], [cdp_Integration]

