
GRANT EXECUTE ON [__mj].[spCreateRecommendationRun] TO [cdp_Integration], [cdp_Developer]

