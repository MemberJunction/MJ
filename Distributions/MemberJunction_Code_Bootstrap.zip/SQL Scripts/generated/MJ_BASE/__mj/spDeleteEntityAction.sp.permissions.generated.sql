
GRANT EXECUTE ON [__mj].[spDeleteEntityAction] TO [cdp_Integration]

