
GRANT EXECUTE ON [__mj].[spUpdateUserNotification] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

