
GRANT EXECUTE ON [__mj].[spUpdateLibraryItem] TO [cdp_Developer], [cdp_Integration]

