
GRANT EXECUTE ON [__mj].[spDeleteEntityBehaviorType] TO [cdp_Integration]

