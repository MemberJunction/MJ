
GRANT EXECUTE ON [__mj].[spCreateConversation] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

