
GRANT EXECUTE ON [__mj].[spDeleteEntityAIAction] TO [cdp_Developer]

