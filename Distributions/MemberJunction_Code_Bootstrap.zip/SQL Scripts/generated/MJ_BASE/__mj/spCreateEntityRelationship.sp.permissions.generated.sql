
GRANT EXECUTE ON [__mj].[spCreateEntityRelationship] TO [cdp_Developer], [cdp_Integration]

