
GRANT EXECUTE ON [__mj].[spCreateRecordMergeDeletionLog] TO [cdp_Integration], [cdp_Developer]

