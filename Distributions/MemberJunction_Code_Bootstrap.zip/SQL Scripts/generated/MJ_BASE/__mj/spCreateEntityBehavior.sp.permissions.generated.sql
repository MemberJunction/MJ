
GRANT EXECUTE ON [__mj].[spCreateEntityBehavior] TO [cdp_Developer], [cdp_Integration]

