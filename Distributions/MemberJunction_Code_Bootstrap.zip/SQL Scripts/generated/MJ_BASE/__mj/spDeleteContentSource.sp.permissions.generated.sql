
GRANT EXECUTE ON [__mj].[spDeleteContentSource] TO [cdp_Integration]

