
GRANT EXECUTE ON [__mj].[spUpdateEntityActionInvocationType] TO [cdp_Developer], [cdp_Integration]

