
GRANT EXECUTE ON [__mj].[spDeleteEntityActionInvocation] TO [cdp_Integration]

