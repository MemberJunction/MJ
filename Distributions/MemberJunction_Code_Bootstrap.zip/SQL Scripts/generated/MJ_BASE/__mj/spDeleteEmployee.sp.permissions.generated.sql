
GRANT EXECUTE ON [__mj].[spDeleteEmployee] TO [cdp_Developer], [cdp_Integration]

