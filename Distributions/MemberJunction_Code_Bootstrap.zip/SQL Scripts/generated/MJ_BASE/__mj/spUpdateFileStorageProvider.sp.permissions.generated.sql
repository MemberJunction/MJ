
GRANT EXECUTE ON [__mj].[spUpdateFileStorageProvider] TO [cdp_Integration], [cdp_Developer]

