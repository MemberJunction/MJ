
GRANT EXECUTE ON [__mj].[spCreateSchemaInfo] TO [cdp_Developer], [cdp_Integration]

