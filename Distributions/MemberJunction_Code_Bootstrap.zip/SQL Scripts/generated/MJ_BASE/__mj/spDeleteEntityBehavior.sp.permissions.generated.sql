
GRANT EXECUTE ON [__mj].[spDeleteEntityBehavior] TO [cdp_Integration]

