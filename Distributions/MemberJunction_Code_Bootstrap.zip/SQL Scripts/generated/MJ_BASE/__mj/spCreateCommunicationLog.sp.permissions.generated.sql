
GRANT EXECUTE ON [__mj].[spCreateCommunicationLog] TO [cdp_Developer], [cdp_Integration]

