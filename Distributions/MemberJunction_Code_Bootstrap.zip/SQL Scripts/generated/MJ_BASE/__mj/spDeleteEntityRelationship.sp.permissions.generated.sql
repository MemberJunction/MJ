
GRANT EXECUTE ON [__mj].[spDeleteEntityRelationship] TO [cdp_Integration], [cdp_Developer]

