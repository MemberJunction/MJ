
GRANT EXECUTE ON [__mj].[spCreateEntityActionInvocation] TO [cdp_Integration], [cdp_Developer]

