
GRANT EXECUTE ON [__mj].[spCreateResourcePermission] TO [cdp_Developer], [cdp_Integration]

