
GRANT EXECUTE ON [__mj].[spUpdateRecommendationRun] TO [cdp_Integration], [cdp_Developer]

