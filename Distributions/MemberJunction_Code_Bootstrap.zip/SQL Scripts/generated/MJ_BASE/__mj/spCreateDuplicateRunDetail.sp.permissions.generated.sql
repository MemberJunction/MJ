
GRANT EXECUTE ON [__mj].[spCreateDuplicateRunDetail] TO [cdp_Developer], [cdp_Integration]

