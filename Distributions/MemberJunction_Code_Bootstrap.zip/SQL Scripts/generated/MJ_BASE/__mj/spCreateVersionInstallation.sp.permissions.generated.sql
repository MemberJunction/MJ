
GRANT EXECUTE ON [__mj].[spCreateVersionInstallation] TO [cdp_Integration], [cdp_Developer]

