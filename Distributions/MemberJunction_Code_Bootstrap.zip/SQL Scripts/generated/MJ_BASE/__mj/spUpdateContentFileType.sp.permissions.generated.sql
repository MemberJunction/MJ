
GRANT EXECUTE ON [__mj].[spUpdateContentFileType] TO [cdp_Developer], [cdp_Integration]

