
GRANT EXECUTE ON [__mj].[spDeleteListDetail] TO [cdp_Integration], [cdp_Developer]

