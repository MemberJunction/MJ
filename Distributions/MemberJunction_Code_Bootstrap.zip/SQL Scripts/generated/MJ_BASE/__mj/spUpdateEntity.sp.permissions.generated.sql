
GRANT EXECUTE ON [__mj].[spUpdateEntity] TO [cdp_Developer], [cdp_Integration]

