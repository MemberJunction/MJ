
GRANT EXECUTE ON [__mj].[spDeleteWorkspace] TO [cdp_UI]

