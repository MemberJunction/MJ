
GRANT EXECUTE ON [__mj].[spDeleteWorkspace] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

