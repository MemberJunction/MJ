
GRANT EXECUTE ON [__mj].[spCreateContentItem] TO [cdp_Developer], [cdp_Integration]

