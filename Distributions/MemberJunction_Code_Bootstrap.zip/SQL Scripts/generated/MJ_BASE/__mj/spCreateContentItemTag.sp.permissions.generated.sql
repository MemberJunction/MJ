
GRANT EXECUTE ON [__mj].[spCreateContentItemTag] TO [cdp_Developer], [cdp_Integration]

