
GRANT EXECUTE ON [__mj].[spDeleteResourceLink] TO [cdp_Integration]

