
GRANT EXECUTE ON [__mj].[spDeleteList] TO [cdp_Integration], [cdp_Developer]

