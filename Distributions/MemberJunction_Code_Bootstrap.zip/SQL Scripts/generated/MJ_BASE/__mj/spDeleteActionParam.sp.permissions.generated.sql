
GRANT EXECUTE ON [__mj].[spDeleteActionParam] TO [cdp_Integration]

