
GRANT EXECUTE ON [__mj].[spCreateRecommendationProvider] TO [cdp_Integration], [cdp_Developer]

