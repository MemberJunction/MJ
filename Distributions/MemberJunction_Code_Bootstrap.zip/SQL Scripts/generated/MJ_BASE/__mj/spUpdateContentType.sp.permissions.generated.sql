
GRANT EXECUTE ON [__mj].[spUpdateContentType] TO [cdp_Developer], [cdp_Integration]

