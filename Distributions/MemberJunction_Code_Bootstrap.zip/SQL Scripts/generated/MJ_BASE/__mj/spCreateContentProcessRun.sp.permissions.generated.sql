
GRANT EXECUTE ON [__mj].[spCreateContentProcessRun] TO [cdp_Developer], [cdp_Integration]

