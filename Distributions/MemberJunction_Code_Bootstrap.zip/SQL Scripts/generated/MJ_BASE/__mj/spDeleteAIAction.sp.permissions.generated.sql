
GRANT EXECUTE ON [__mj].[spDeleteAIAction] TO [cdp_Developer]

