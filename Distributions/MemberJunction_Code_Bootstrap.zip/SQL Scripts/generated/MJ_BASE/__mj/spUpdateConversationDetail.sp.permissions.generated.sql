
GRANT EXECUTE ON [__mj].[spUpdateConversationDetail] TO [cdp_UI]

