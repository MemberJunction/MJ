
GRANT EXECUTE ON [__mj].[spUpdateConversationDetail] TO [cdp_Developer], [cdp_UI], [cdp_Integration]

