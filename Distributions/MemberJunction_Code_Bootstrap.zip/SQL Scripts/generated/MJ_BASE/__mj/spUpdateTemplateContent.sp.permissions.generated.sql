
GRANT EXECUTE ON [__mj].[spUpdateTemplateContent] TO [cdp_Integration], [cdp_Developer]

