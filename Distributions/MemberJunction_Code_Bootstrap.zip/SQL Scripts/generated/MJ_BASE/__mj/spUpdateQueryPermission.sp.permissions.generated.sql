
GRANT EXECUTE ON [__mj].[spUpdateQueryPermission] TO [cdp_Developer], [cdp_Integration]

