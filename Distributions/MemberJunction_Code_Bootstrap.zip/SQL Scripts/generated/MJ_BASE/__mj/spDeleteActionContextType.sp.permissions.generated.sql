
GRANT EXECUTE ON [__mj].[spDeleteActionContextType] TO [cdp_Integration]

