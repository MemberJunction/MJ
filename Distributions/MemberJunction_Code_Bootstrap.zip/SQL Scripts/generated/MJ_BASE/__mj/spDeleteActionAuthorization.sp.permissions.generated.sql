
GRANT EXECUTE ON [__mj].[spDeleteActionAuthorization] TO [cdp_Integration]

