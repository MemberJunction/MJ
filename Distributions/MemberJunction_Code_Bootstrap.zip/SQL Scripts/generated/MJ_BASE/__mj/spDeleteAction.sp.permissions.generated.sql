
GRANT EXECUTE ON [__mj].[spDeleteAction] TO [cdp_Integration]

