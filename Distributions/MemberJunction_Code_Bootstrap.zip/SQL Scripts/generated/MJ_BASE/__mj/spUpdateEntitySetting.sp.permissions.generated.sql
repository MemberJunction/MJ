
GRANT EXECUTE ON [__mj].[spUpdateEntitySetting] TO [cdp_Integration], [cdp_Developer]

