
GRANT EXECUTE ON [__mj].[spUpdateRecordMergeLog] TO [cdp_Integration], [cdp_Developer]

