
GRANT EXECUTE ON [__mj].[spCreateActionFilter] TO [cdp_Integration], [cdp_Developer]

