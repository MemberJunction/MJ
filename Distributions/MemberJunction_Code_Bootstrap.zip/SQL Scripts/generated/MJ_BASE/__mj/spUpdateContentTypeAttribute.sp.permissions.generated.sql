
GRANT EXECUTE ON [__mj].[spUpdateContentTypeAttribute] TO [cdp_Developer], [cdp_Integration]

