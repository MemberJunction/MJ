
GRANT EXECUTE ON [__mj].[spUpdateWorkflowEngine] TO [cdp_Developer], [cdp_Integration]

