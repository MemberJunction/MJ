
GRANT EXECUTE ON [__mj].[spDeleteContentFileType] TO [cdp_Integration]

