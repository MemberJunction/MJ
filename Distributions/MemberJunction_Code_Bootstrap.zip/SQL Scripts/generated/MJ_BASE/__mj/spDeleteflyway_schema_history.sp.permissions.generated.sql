
GRANT EXECUTE ON [__mj].[spDeleteflyway_schema_history] TO [cdp_Integration]

