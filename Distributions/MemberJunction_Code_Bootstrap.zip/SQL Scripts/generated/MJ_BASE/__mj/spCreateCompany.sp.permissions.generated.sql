
GRANT EXECUTE ON [__mj].[spCreateCompany] TO [cdp_UI], [cdp_Integration], [cdp_Developer]

