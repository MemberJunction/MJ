
GRANT EXECUTE ON [__mj].[spCreateCompany] TO [cdp_Developer], [cdp_Integration]

