
GRANT EXECUTE ON [__mj].[spCreateEntityActionParam] TO [cdp_Developer], [cdp_Integration]

