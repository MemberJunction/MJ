
GRANT EXECUTE ON [__mj].[spDeleteReportCategory] TO [cdp_Integration], [cdp_Developer], [cdp_UI]

