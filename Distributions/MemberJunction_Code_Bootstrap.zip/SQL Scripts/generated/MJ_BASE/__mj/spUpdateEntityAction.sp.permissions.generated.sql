
GRANT EXECUTE ON [__mj].[spUpdateEntityAction] TO [cdp_Integration], [cdp_Developer]

