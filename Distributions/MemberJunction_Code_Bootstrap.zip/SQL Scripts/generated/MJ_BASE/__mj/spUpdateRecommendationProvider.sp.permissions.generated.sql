
GRANT EXECUTE ON [__mj].[spUpdateRecommendationProvider] TO [cdp_Integration], [cdp_Developer]

