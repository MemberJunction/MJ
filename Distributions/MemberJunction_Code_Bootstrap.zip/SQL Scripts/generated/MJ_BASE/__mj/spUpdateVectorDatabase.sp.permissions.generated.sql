
GRANT EXECUTE ON [__mj].[spUpdateVectorDatabase] TO [cdp_Integration], [cdp_Developer]

