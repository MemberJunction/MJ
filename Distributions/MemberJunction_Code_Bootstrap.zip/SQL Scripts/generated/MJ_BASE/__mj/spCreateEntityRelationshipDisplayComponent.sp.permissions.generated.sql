
GRANT EXECUTE ON [__mj].[spCreateEntityRelationshipDisplayComponent] TO [cdp_Integration], [cdp_Developer]

