
GRANT EXECUTE ON [__mj].[spDeleteContentSourceTypeParam] TO [cdp_Integration]

