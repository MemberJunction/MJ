
GRANT EXECUTE ON [__mj].[spUpdateDashboard] TO [cdp_UI]

