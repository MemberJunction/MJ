
GRANT EXECUTE ON [__mj].[spCreateEntityActionFilter] TO [cdp_Integration], [cdp_Developer]

