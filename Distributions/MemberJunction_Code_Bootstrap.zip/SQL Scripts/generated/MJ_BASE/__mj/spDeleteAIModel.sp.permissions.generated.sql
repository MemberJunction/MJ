
GRANT EXECUTE ON [__mj].[spDeleteAIModel] TO [cdp_Developer]

