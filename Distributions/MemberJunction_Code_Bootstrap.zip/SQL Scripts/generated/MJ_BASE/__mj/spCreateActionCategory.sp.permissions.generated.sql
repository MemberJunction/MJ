
GRANT EXECUTE ON [__mj].[spCreateActionCategory] TO [cdp_Integration], [cdp_Developer]

