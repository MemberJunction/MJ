
GRANT EXECUTE ON [__mj].[spDeleteExplorerNavigationItem] TO [cdp_Integration], [cdp_Developer]

