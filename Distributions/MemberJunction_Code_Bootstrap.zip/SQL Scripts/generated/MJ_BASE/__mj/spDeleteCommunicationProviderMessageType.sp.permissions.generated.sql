
GRANT EXECUTE ON [__mj].[spDeleteCommunicationProviderMessageType] TO [cdp_Integration]

