
GRANT EXECUTE ON [__mj].[spCreateCompanyIntegrationRun] TO [cdp_Developer], [cdp_Integration]

