
GRANT EXECUTE ON [__mj].[spCreateActionContextType] TO [cdp_Developer], [cdp_Integration]

