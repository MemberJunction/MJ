
GRANT EXECUTE ON [__mj].[spDeleteActionContext] TO [cdp_Integration]

