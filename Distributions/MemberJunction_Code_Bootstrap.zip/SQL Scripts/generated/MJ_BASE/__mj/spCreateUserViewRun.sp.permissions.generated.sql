
GRANT EXECUTE ON [__mj].[spCreateUserViewRun] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

