
GRANT EXECUTE ON [__mj].[spDeleteEntityActionInvocationType] TO [cdp_Integration]

