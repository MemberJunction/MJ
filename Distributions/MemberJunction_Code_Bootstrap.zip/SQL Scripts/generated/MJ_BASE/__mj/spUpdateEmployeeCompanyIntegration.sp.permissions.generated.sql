
GRANT EXECUTE ON [__mj].[spUpdateEmployeeCompanyIntegration] TO [cdp_Developer], [cdp_Integration]

