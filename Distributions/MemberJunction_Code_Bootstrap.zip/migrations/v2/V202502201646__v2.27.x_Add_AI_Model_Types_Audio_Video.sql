INSERT INTO ${flyway:defaultSchema}.AIModelType 
( ID, Name, Description )
VALUES
(
  '5F75433E-F36B-1410-8D99-00021F8B792E', 'Audio', 'Audio Generation Model'
)
INSERT INTO ${flyway:defaultSchema}.AIModelType 
( ID, Name, Description )
VALUES
(
  '6175433E-F36B-1410-8D99-00021F8B792E', 'Video', 'Video Generation Model'
)
