-- Groq updated Kimi K2 to the new version with better performance and lower cost.
UPDATE ${flyway:defaultSchema}.AIModelVendor Set APIName='moonshotai/kimi-k2-instruct-0905' WHERE ID='DA60EB91-B2BC-4F24-BFEE-4DEAB8959ADF'
