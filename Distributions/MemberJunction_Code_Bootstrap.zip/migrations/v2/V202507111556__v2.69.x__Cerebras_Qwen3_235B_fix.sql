update ${flyway:defaultSchema}.AIModelVendor SET APIName='qwen-3-235b-a22b' WHERE ID='4CB2443E-F36B-1410-8DB7-00021F8B792E'
