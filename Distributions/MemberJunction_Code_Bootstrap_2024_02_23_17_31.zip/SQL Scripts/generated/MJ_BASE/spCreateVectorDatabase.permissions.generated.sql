
GRANT EXECUTE ON [admin].[spCreateVectorDatabase] TO [cdp_Developer], [cdp_Integration]

