
GRANT EXECUTE ON [admin].[spUpdateWorkspaceItem] TO [cdp_UI]

