
GRANT EXECUTE ON [admin].[spUpdateEmployeeRole] TO [cdp_Developer], [cdp_Integration]

