
GRANT EXECUTE ON [__mj].[spUpdateEmployeeSkill] TO [cdp_Developer], [cdp_Integration]

