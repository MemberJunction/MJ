
GRANT EXECUTE ON [__mj].[spUpdateList] TO [cdp_Developer], [cdp_Integration]

