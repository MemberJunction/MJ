
GRANT EXECUTE ON [__mj].[spUpdateEntityField] TO [cdp_Developer], [cdp_Integration]

