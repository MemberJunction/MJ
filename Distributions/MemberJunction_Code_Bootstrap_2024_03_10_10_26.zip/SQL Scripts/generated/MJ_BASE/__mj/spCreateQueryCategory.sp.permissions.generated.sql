
GRANT EXECUTE ON [__mj].[spCreateQueryCategory] TO [cdp_Developer], [cdp_Integration]

