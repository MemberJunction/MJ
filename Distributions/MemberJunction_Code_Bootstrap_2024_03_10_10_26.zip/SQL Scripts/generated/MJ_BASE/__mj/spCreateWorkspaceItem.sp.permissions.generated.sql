
GRANT EXECUTE ON [__mj].[spCreateWorkspaceItem] TO [cdp_UI]

