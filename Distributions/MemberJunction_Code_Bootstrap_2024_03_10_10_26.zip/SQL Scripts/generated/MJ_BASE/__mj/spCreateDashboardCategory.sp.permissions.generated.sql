
GRANT EXECUTE ON [__mj].[spCreateDashboardCategory] TO [cdp_Developer], [cdp_Integration]

