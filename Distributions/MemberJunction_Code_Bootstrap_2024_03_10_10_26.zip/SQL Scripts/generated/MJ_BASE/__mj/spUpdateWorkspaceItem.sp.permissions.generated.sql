
GRANT EXECUTE ON [__mj].[spUpdateWorkspaceItem] TO [cdp_UI]

