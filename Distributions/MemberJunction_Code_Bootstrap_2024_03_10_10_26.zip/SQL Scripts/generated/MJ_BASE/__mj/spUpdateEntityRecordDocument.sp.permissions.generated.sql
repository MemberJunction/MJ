
GRANT EXECUTE ON [__mj].[spUpdateEntityRecordDocument] TO [cdp_Developer], [cdp_Integration]

