
GRANT EXECUTE ON [__mj].[spUpdateQueue] TO [cdp_Developer], [cdp_Developer]

