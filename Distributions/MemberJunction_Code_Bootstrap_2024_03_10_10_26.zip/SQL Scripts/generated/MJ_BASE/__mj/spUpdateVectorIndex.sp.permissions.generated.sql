
GRANT EXECUTE ON [__mj].[spUpdateVectorIndex] TO [cdp_Developer], [cdp_Integration]

