
GRANT EXECUTE ON [__mj].[spUpdateReportCategory] TO [cdp_Developer], [cdp_Integration]

