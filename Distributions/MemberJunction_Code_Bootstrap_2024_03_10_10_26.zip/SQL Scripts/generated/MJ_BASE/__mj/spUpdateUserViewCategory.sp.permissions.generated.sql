
GRANT EXECUTE ON [__mj].[spUpdateUserViewCategory] TO [cdp_Developer], [cdp_Integration]

