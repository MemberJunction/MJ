
GRANT EXECUTE ON [dbo].[spUpdateAnothaTabla] TO [cdp_Developer], [cdp_Integration]

