                -- CREATE THE FULL TEXT CATALOG FOR THE ENTITY, IF NOT ALREADY CREATED
                IF NOT EXISTS (
                    SELECT * 
                    FROM sys.fulltext_catalogs 
                    WHERE name = 'full_text_test'
                )
                    CREATE FULLTEXT CATALOG full_text_test;
                GO
                -- DROP AND RECREATE THE FULL TEXT INDEX
                IF EXISTS (
                    SELECT * 
                    FROM sys.fulltext_indexes 
                    WHERE object_id = OBJECT_ID('crm.Account')
                )
                BEGIN
                    DROP FULLTEXT INDEX ON [crm].[Account];
                END
                GO
                
                IF NOT EXISTS (
                    SELECT * 
                    FROM sys.fulltext_indexes 
                    WHERE object_id = OBJECT_ID('crm.Account')
                )
                BEGIN
                    CREATE FULLTEXT INDEX ON [crm].[Account]
                    (
                        Name LANGUAGE 'English', Acronym LANGUAGE 'English', OperatingName LANGUAGE 'English', DisplayName LANGUAGE 'English', Description LANGUAGE 'English', City LANGUAGE 'English', StateProvince LANGUAGE 'English', PostalCode LANGUAGE 'English', Country LANGUAGE 'English', Domain LANGUAGE 'English', Website LANGUAGE 'English'
                    )
                    KEY INDEX PK__Account__3214EC273BD799F7 
                    ON full_text_test;
                END
                GO
                -- DROP AND RECREATE THE FULL TEXT SEARCH FUNCTION
                -- Create an inline table-valued function to perform full-text search
                -- Drop the function if it already exists
                IF OBJECT_ID('crm.fnSearchAccounts', 'IF') IS NOT NULL
                    DROP FUNCTION crm.fnSearchAccounts;
                GO
                CREATE FUNCTION crm.fnSearchAccounts (@searchTerm NVARCHAR(255))
                RETURNS TABLE
                AS
                RETURN (
                    SELECT [ID]
                    FROM [crm].[Account]
                    WHERE CONTAINS(([Name], [Acronym], [OperatingName], [DisplayName], [Description], [City], [StateProvince], [PostalCode], [Country], [Domain], [Website]), @searchTerm)
                )
                GO

GRANT SELECT ON [crm].[fnSearchAccounts] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

GO
