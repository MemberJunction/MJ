
GRANT EXECUTE ON [__mj].[spCreateEntityDocument] TO [cdp_Developer], [cdp_Integration]

