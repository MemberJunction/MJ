
GRANT EXECUTE ON [__mj].[spCreateReportSnapshot] TO [cdp_UI]

