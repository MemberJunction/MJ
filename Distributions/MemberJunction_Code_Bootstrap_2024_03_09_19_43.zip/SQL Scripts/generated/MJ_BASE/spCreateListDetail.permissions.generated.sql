
GRANT EXECUTE ON [__mj].[spCreateListDetail] TO [cdp_Developer], [cdp_Integration]

