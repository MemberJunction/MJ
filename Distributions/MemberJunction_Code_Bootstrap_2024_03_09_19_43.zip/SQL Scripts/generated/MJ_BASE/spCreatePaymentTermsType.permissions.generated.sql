
GRANT EXECUTE ON [crm].[spCreatePaymentTermsType] TO [cdp_Developer], [cdp_Integration]

