
GRANT EXECUTE ON [__mj].[spUpdateQueryField] TO [cdp_Developer], [cdp_Integration]

