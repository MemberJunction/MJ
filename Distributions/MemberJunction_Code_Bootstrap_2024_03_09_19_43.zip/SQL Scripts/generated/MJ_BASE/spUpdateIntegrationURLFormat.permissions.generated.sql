
GRANT EXECUTE ON [__mj].[spUpdateIntegrationURLFormat] TO [cdp_Developer], [cdp_Integration]

