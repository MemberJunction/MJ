
GRANT EXECUTE ON [crm].[spUpdateAccount] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

