
GRANT EXECUTE ON [__mj].[spCreateRecordChange] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

