
GRANT EXECUTE ON [reference].[spCreateContactRole] TO [cdp_Developer], [cdp_Integration]

