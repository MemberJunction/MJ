import { BaseEntity } from "@memberjunction/core";
import { RegisterClass } from "@memberjunction/global";
