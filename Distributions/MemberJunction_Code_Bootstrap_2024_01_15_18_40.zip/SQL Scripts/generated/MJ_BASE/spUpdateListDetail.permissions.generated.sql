
GRANT EXECUTE ON [admin].[spUpdateListDetail] TO [cdp_Developer], [cdp_Integration]

