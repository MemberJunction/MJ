
GRANT EXECUTE ON [admin].[spUpdateEntity] TO [cdp_Developer], [cdp_Integration]

