
GRANT EXECUTE ON [admin].[spUpdateDashboard] TO [cdp_UI]

