
GRANT EXECUTE ON [admin].[spCreateCompany] TO [cdp_Developer], [cdp_Integration]

