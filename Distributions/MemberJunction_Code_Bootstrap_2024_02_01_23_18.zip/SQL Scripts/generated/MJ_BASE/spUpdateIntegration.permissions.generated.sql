
GRANT EXECUTE ON [admin].[spUpdateIntegration] TO [cdp_Developer], [cdp_Integration]

