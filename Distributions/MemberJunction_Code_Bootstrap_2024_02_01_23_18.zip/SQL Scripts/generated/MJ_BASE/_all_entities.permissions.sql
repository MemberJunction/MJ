
GRANT EXECUTE ON [dbo].[spCreateAnothaTabla] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateApplicationEntity] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateAuditLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateCompany] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateCompanyIntegrationRecordMap] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateConversation] TO [cdp_UI], [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateConversationDetail] TO [cdp_UI], [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateDashboard] TO [cdp_UI]





GRANT EXECUTE ON [dbo].[spCreateDemoKey] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateEmployee] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateEntity] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateEntityField] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateEntityPermission] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateEntityRelationship] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateList] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateListDetail] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [dbo].[spCreatePerson] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateQueue] TO [cdp_Developer], [cdp_Developer], [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateQueueTask] TO [cdp_Developer], [cdp_Developer], [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateRecordChange] TO [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateRecordMergeDeletionLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateRecordMergeLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateReport] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateReportSnapshot] TO [cdp_UI]















GRANT EXECUTE ON [admin].[spCreateUser] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateUserFavorite] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateUserNotification] TO [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateUserRole] TO [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateUserView] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateUserViewRun] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateUserViewRunDetail] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spCreateWorkspace] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spCreateWorkspaceItem] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteApplicationEntity] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteCompany] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteConversation] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteConversationDetail] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteDashboard] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteEmployee] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteEntity] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteEntityField] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteEntityPermission] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteEntityRelationship] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteList] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteListDetail] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteReport] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteReportSnapshot] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spDeleteUserFavorite] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteUserView] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteWorkspace] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spDeleteWorkspaceItem] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spUpdateAIAction] TO [cdp_Integration], [cdp_Developer]





GRANT EXECUTE ON [admin].[spUpdateAIModel] TO [cdp_Integration], [cdp_Developer]





GRANT EXECUTE ON [admin].[spUpdateAIModelAction] TO [cdp_Integration], [cdp_Developer]





GRANT EXECUTE ON [admin].[spUpdateAIModelType] TO [cdp_Integration], [cdp_Developer]





GRANT EXECUTE ON [dbo].[spUpdateAnothaTabla] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateApplication] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateApplicationEntity] TO [cdp_Developer], [cdp_Integration]










GRANT EXECUTE ON [admin].[spUpdateCompany] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateCompanyIntegration] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateCompanyIntegrationRecordMap] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateCompanyIntegrationRun] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateCompanyIntegrationRunAPILog] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateCompanyIntegrationRunDetail] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateConversation] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spUpdateConversationDetail] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spUpdateDashboard] TO [cdp_UI]





GRANT EXECUTE ON [dbo].[spUpdateDemoKey] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateEmployee] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateEmployeeCompanyIntegration] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateEmployeeRole] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateEmployeeSkill] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateEntity] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateEntityAIAction] TO [cdp_Integration], [cdp_Developer]





GRANT EXECUTE ON [admin].[spUpdateEntityField] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateEntityPermission] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateEntityRelationship] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateErrorLog] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateIntegration] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateIntegrationURLFormat] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateList] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateListDetail] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [dbo].[spUpdatePerson] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateQueue] TO [cdp_Developer], [cdp_Developer]





GRANT EXECUTE ON [admin].[spUpdateQueueTask] TO [cdp_Developer], [cdp_Developer]





GRANT EXECUTE ON [admin].[spUpdateRecordMergeDeletionLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateRecordMergeLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateReport] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spUpdateReportSnapshot] TO [cdp_UI]










GRANT EXECUTE ON [admin].[spUpdateRole] TO [cdp_Developer], [cdp_Integration]










GRANT EXECUTE ON [admin].[spUpdateUser] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateUserApplication] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateUserFavorite] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spUpdateUserNotification] TO [cdp_UI], [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateUserRecordLog] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateUserView] TO [cdp_Developer], [cdp_Integration], [cdp_UI]





GRANT EXECUTE ON [admin].[spUpdateUserViewRun] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateUserViewRunDetail] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateWorkflow] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateWorkflowEngine] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateWorkflowRun] TO [cdp_Developer], [cdp_Integration]





GRANT EXECUTE ON [admin].[spUpdateWorkspace] TO [cdp_UI]





GRANT EXECUTE ON [admin].[spUpdateWorkspaceItem] TO [cdp_UI]




-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: AI Actions
-- Item: Permissions for vwAIActions
-- Generated: 2/1/2024, 11:09:04 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwAIActions] TO [cdp_UI], [cdp_Integration], [cdp_Developer]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: AI Model Actions
-- Item: Permissions for vwAIModelActions
-- Generated: 2/1/2024, 11:09:04 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwAIModelActions] TO [cdp_UI], [cdp_Integration], [cdp_Developer]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: AI Models
-- Item: Permissions for vwAIModels
-- Generated: 2/1/2024, 11:09:04 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwAIModels] TO [cdp_UI], [cdp_Integration], [cdp_Developer]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: AI Model Types
-- Item: Permissions for vwAIModelTypes
-- Generated: 2/1/2024, 11:09:06 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwAIModelTypes] TO [cdp_UI], [cdp_Integration], [cdp_Developer]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Anotha Tablas
-- Item: Permissions for vwAnothaTablas
-- Generated: 1/26/2024, 10:50:39 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [dbo].[vwAnothaTablas] TO [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Application Entities
-- Item: Permissions for vwApplicationEntities
-- Generated: 2/1/2024, 11:08:54 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwApplicationEntities] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Applications
-- Item: Permissions for vwApplications
-- Generated: 2/1/2024, 11:08:54 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwApplications] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Audit Logs
-- Item: Permissions for vwAuditLogs
-- Generated: 2/1/2024, 11:09:02 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwAuditLogs] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Audit Log Types
-- Item: Permissions for vwAuditLogTypes
-- Generated: 2/1/2024, 11:09:02 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwAuditLogTypes] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Authorization Roles
-- Item: Permissions for vwAuthorizationRoles
-- Generated: 2/1/2024, 11:09:02 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwAuthorizationRoles] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Authorizations
-- Item: Permissions for vwAuthorizations
-- Generated: 2/1/2024, 11:09:02 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwAuthorizations] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Companies
-- Item: Permissions for vwCompanies
-- Generated: 2/1/2024, 11:08:44 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwCompanies] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Company Integration Record Maps
-- Item: Permissions for vwCompanyIntegrationRecordMaps
-- Generated: 2/1/2024, 11:09:17 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwCompanyIntegrationRecordMaps] TO [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Company Integration Run API Logs
-- Item: Permissions for vwCompanyIntegrationRunAPILogs
-- Generated: 2/1/2024, 11:08:57 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwCompanyIntegrationRunAPILogs] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Company Integration Run Details
-- Item: Permissions for vwCompanyIntegrationRunDetails
-- Generated: 2/1/2024, 11:08:52 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwCompanyIntegrationRunDetails] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Company Integration Runs
-- Item: Permissions for vwCompanyIntegrationRuns
-- Generated: 2/1/2024, 11:08:52 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwCompanyIntegrationRuns] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Company Integrations
-- Item: Permissions for vwCompanyIntegrations
-- Generated: 2/1/2024, 11:08:50 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwCompanyIntegrations] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Conversation Details
-- Item: Permissions for vwConversationDetails
-- Generated: 2/1/2024, 11:09:14 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwConversationDetails] TO [cdp_UI], [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Conversations
-- Item: Permissions for vwConversations
-- Generated: 2/1/2024, 11:09:14 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwConversations] TO [cdp_UI], [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Dashboards
-- Item: Permissions for vwDashboards
-- Generated: 2/1/2024, 11:09:06 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwDashboards] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Dataset Items
-- Item: Permissions for vwDatasetItems
-- Generated: 2/1/2024, 11:09:14 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwDatasetItems] TO [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Datasets
-- Item: Permissions for vwDatasets
-- Generated: 2/1/2024, 11:09:14 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwDatasets] TO [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Demo Keys
-- Item: Permissions for vwDemoKeys
-- Generated: 1/26/2024, 10:50:39 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [dbo].[vwDemoKeys] TO [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Employee Company Integrations
-- Item: Permissions for vwEmployeeCompanyIntegrations
-- Generated: 2/1/2024, 11:08:44 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEmployeeCompanyIntegrations] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Employee Roles
-- Item: Permissions for vwEmployeeRoles
-- Generated: 2/1/2024, 11:08:44 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEmployeeRoles] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Employees
-- Item: Permissions for vwEmployees
-- Generated: 2/1/2024, 11:08:43 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEmployees] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Employee Skills
-- Item: Permissions for vwEmployeeSkills
-- Generated: 2/1/2024, 11:08:48 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEmployeeSkills] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Entities
-- Item: Permissions for vwEntities
-- Generated: 2/1/2024, 11:08:50 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEntities] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Entity AI Actions
-- Item: Permissions for vwEntityAIActions
-- Generated: 2/1/2024, 11:09:04 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEntityAIActions] TO [cdp_UI], [cdp_Integration], [cdp_Developer]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Entity Fields
-- Item: Permissions for vwEntityFields
-- Generated: 2/1/2024, 11:08:50 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEntityFields] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Entity Field Values
-- Item: Permissions for vwEntityFieldValues
-- Generated: 2/1/2024, 11:09:04 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEntityFieldValues] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Entity Permissions
-- Item: Permissions for vwEntityPermissions
-- Generated: 2/1/2024, 11:08:54 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEntityPermissions] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Entity Relationships
-- Item: Permissions for vwEntityRelationships
-- Generated: 2/1/2024, 11:08:50 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwEntityRelationships] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Error Logs
-- Item: Permissions for vwErrorLogs
-- Generated: 2/1/2024, 11:08:52 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwErrorLogs] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Integrations
-- Item: Permissions for vwIntegrations
-- Generated: 2/1/2024, 11:08:48 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwIntegrations] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Integration URL Formats
-- Item: Permissions for vwIntegrationURLFormats
-- Generated: 2/1/2024, 11:08:48 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwIntegrationURLFormats] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: List Details
-- Item: Permissions for vwListDetails
-- Generated: 2/1/2024, 11:08:57 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwListDetails] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Lists
-- Item: Permissions for vwLists
-- Generated: 2/1/2024, 11:08:57 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwLists] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Output Delivery Types
-- Item: Permissions for vwOutputDeliveryTypes
-- Generated: 2/1/2024, 11:09:08 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwOutputDeliveryTypes] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Output Format Types
-- Item: Permissions for vwOutputFormatTypes
-- Generated: 2/1/2024, 11:09:08 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwOutputFormatTypes] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Output Trigger Types
-- Item: Permissions for vwOutputTriggerTypes
-- Generated: 2/1/2024, 11:09:08 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwOutputTriggerTypes] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Persons
-- Item: Permissions for vwPersons
-- Generated: 1/26/2024, 10:50:39 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [dbo].[vwPersons] TO [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Queues
-- Item: Permissions for vwQueues
-- Generated: 2/1/2024, 11:09:06 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwQueues] TO [cdp_Developer], [cdp_Developer], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Queue Tasks
-- Item: Permissions for vwQueueTasks
-- Generated: 2/1/2024, 11:09:06 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwQueueTasks] TO [cdp_Developer], [cdp_Developer], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Queue Types
-- Item: Permissions for vwQueueTypes
-- Generated: 2/1/2024, 11:09:06 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwQueueTypes] TO [cdp_Developer]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Record Changes
-- Item: Permissions for vwRecordChanges
-- Generated: 2/1/2024, 11:09:00 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwRecordChanges] TO [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Record Merge Deletion Logs
-- Item: Permissions for vwRecordMergeDeletionLogs
-- Generated: 2/1/2024, 11:09:17 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwRecordMergeDeletionLogs] TO [cdp_UI], [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Record Merge Logs
-- Item: Permissions for vwRecordMergeLogs
-- Generated: 2/1/2024, 11:09:17 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwRecordMergeLogs] TO [cdp_UI], [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Reports
-- Item: Permissions for vwReports
-- Generated: 2/1/2024, 11:09:08 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwReports] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Report Snapshots
-- Item: Permissions for vwReportSnapshots
-- Generated: 2/1/2024, 11:09:08 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwReportSnapshots] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Resource Folders
-- Item: Permissions for vwResourceFolders
-- Generated: 2/1/2024, 11:09:17 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------



-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Resource Types
-- Item: Permissions for vwResourceTypes
-- Generated: 2/1/2024, 11:09:11 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwResourceTypes] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Roles
-- Item: Permissions for vwRoles
-- Generated: 2/1/2024, 11:08:48 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwRoles] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Row Level Security Filters
-- Item: Permissions for vwRowLevelSecurityFilters
-- Generated: 2/1/2024, 11:09:02 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwRowLevelSecurityFilters] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Schema Info
-- Item: Permissions for vwSchemaInfos
-- Generated: 2/1/2024, 11:09:17 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------



-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Skills
-- Item: Permissions for vwSkills
-- Generated: 2/1/2024, 11:08:48 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwSkills] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Tagged Items
-- Item: Permissions for vwTaggedItems
-- Generated: 2/1/2024, 11:09:11 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwTaggedItems] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Tags
-- Item: Permissions for vwTags
-- Generated: 2/1/2024, 11:09:11 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwTags] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User Application Entities
-- Item: Permissions for vwUserApplicationEntities
-- Generated: 2/1/2024, 11:08:54 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserApplicationEntities] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User Applications
-- Item: Permissions for vwUserApplications
-- Generated: 2/1/2024, 11:08:54 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserApplications] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User Favorites
-- Item: Permissions for vwUserFavorites
-- Generated: 2/1/2024, 11:08:43 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserFavorites] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User Notifications
-- Item: Permissions for vwUserNotifications
-- Generated: 2/1/2024, 11:09:14 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserNotifications] TO [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User Record Logs
-- Item: Permissions for vwUserRecordLogs
-- Generated: 2/1/2024, 11:08:52 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserRecordLogs] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User Roles
-- Item: Permissions for vwUserRoles
-- Generated: 2/1/2024, 11:09:00 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserRoles] TO [cdp_UI], [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Users
-- Item: Permissions for vwUsers
-- Generated: 2/1/2024, 11:08:50 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUsers] TO [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User View Run Details
-- Item: Permissions for vwUserViewRunDetails
-- Generated: 2/1/2024, 11:08:57 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserViewRunDetails] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User View Runs
-- Item: Permissions for vwUserViewRuns
-- Generated: 2/1/2024, 11:08:57 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserViewRuns] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: User Views
-- Item: Permissions for vwUserViews
-- Generated: 2/1/2024, 11:08:52 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwUserViews] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Workflow Engines
-- Item: Permissions for vwWorkflowEngines
-- Generated: 2/1/2024, 11:09:00 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwWorkflowEngines] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Workflow Runs
-- Item: Permissions for vwWorkflowRuns
-- Generated: 2/1/2024, 11:09:00 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwWorkflowRuns] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Workflows
-- Item: Permissions for vwWorkflows
-- Generated: 2/1/2024, 11:09:00 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwWorkflows] TO [cdp_Developer], [cdp_Integration], [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Workspace Items
-- Item: Permissions for vwWorkspaceItems
-- Generated: 2/1/2024, 11:09:11 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwWorkspaceItems] TO [cdp_UI]


-----------------------------------------------------------------
-- SQL Code Generation
-- Entity: Workspaces
-- Item: Permissions for vwWorkspaces
-- Generated: 2/1/2024, 11:09:11 PM
--
-- This was generated by the Entity Generator.
-- This file should NOT be edited by hand.
-----------------------------------------------------------------

GRANT SELECT ON [admin].[vwWorkspaces] TO [cdp_UI]


