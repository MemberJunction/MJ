
GRANT EXECUTE ON [admin].[spUpdateWorkflowEngine] TO [cdp_Developer], [cdp_Integration]

