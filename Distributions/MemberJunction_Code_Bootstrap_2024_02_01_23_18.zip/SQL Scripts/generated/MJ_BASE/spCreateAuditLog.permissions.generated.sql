
GRANT EXECUTE ON [admin].[spCreateAuditLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

