
GRANT EXECUTE ON [admin].[spCreateEntity] TO [cdp_Developer], [cdp_Integration]

