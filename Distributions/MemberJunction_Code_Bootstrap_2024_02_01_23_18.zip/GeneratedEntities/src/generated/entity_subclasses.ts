import { BaseEntity, PrimaryKeyValue, EntitySaveOptions } from "@memberjunction/core";
import { RegisterClass } from "@memberjunction/global";
