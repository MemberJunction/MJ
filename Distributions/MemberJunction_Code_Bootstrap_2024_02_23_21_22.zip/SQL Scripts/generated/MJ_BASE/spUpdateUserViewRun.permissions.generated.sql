
GRANT EXECUTE ON [admin].[spUpdateUserViewRun] TO [cdp_Developer], [cdp_Integration]

