
GRANT EXECUTE ON [admin].[spUpdateEntityRecordDocument] TO [cdp_Developer], [cdp_Integration]

