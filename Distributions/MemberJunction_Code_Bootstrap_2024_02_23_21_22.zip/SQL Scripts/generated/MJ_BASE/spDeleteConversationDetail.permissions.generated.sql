
GRANT EXECUTE ON [admin].[spDeleteConversationDetail] TO [cdp_UI]

