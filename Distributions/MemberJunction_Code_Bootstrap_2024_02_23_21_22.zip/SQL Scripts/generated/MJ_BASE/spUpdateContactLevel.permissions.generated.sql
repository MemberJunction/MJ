
GRANT EXECUTE ON [reference].[spUpdateContactLevel] TO [cdp_Developer], [cdp_Integration]

