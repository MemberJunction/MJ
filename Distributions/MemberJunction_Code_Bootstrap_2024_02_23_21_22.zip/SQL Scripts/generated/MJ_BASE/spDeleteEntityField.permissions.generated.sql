
GRANT EXECUTE ON [admin].[spDeleteEntityField] TO [cdp_Developer], [cdp_Integration]

