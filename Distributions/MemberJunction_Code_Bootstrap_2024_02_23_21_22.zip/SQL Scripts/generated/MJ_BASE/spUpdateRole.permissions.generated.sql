
GRANT EXECUTE ON [admin].[spUpdateRole] TO [cdp_Developer], [cdp_Integration]

