
GRANT EXECUTE ON [admin].[spDeleteApplicationEntity] TO [cdp_Developer], [cdp_Integration]

