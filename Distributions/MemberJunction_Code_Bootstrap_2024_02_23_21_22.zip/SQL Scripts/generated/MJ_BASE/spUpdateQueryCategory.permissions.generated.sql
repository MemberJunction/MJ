
GRANT EXECUTE ON [admin].[spUpdateQueryCategory] TO [cdp_Developer], [cdp_Integration]

