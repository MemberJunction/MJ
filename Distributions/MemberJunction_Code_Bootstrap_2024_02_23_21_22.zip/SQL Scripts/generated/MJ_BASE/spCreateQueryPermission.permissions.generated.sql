
GRANT EXECUTE ON [admin].[spCreateQueryPermission] TO [cdp_Developer], [cdp_Integration]

