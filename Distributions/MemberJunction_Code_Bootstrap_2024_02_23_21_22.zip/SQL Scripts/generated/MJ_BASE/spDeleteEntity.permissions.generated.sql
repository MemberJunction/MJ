
GRANT EXECUTE ON [admin].[spDeleteEntity] TO [cdp_Developer], [cdp_Integration]

