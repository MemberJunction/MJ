
GRANT EXECUTE ON [admin].[spCreateEntityRecordDocument] TO [cdp_Developer], [cdp_Integration]

