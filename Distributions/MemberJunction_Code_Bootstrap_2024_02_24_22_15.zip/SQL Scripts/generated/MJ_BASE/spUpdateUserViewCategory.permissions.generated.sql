
GRANT EXECUTE ON [admin].[spUpdateUserViewCategory] TO [cdp_Developer], [cdp_Integration]

