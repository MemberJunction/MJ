
GRANT EXECUTE ON [admin].[spCreateUserViewRun] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

