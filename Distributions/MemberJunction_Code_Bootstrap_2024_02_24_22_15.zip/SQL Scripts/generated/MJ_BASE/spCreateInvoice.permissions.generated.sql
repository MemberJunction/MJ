
GRANT EXECUTE ON [crm].[spCreateInvoice] TO [cdp_Developer], [cdp_Integration]

