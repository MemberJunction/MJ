
GRANT EXECUTE ON [admin].[spUpdateApplicationEntity] TO [cdp_Developer], [cdp_Integration]

