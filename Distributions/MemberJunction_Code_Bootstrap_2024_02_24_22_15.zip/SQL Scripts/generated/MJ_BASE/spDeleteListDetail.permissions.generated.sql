
GRANT EXECUTE ON [admin].[spDeleteListDetail] TO [cdp_Developer], [cdp_Integration]

