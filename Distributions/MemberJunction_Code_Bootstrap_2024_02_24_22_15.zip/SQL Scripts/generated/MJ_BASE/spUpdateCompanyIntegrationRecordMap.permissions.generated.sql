
GRANT EXECUTE ON [admin].[spUpdateCompanyIntegrationRecordMap] TO [cdp_Developer], [cdp_Integration]

