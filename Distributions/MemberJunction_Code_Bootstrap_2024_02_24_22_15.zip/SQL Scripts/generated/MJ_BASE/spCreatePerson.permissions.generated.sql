
GRANT EXECUTE ON [dbo].[spCreatePerson] TO [cdp_Developer], [cdp_Integration]

