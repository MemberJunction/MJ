
GRANT EXECUTE ON [admin].[spUpdateQueryField] TO [cdp_Developer], [cdp_Integration]

