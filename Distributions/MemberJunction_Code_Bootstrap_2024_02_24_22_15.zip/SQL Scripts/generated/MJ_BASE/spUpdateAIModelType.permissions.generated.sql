
GRANT EXECUTE ON [admin].[spUpdateAIModelType] TO [cdp_Integration], [cdp_Developer]

