
GRANT EXECUTE ON [__mj].[spCreateApplication] TO [cdp_Developer], [cdp_Integration]

