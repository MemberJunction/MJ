
GRANT EXECUTE ON [__mj].[spCreateVersionInstallation] TO [cdp_Developer], [cdp_Integration]

