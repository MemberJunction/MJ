
GRANT EXECUTE ON [__mj].[spUpdateFileStorageProvider] TO [cdp_Developer], [cdp_Integration]

