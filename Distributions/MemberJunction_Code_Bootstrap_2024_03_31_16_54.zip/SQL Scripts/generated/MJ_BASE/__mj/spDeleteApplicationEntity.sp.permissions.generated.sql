
GRANT EXECUTE ON [__mj].[spDeleteApplicationEntity] TO [cdp_Developer], [cdp_Integration]

