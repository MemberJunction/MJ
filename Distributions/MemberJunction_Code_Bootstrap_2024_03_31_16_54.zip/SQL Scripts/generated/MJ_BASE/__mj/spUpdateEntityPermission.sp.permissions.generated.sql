
GRANT EXECUTE ON [__mj].[spUpdateEntityPermission] TO [cdp_Developer], [cdp_Integration]

