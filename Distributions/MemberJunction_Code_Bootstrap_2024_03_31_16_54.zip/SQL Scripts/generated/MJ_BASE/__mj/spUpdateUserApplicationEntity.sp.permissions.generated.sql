
GRANT EXECUTE ON [__mj].[spUpdateUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]

