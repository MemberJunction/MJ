
GRANT EXECUTE ON [__mj].[spUpdateConversation] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

