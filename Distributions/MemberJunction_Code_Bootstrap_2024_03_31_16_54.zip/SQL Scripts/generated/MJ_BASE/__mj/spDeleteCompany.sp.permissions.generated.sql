
GRANT EXECUTE ON [__mj].[spDeleteCompany] TO [cdp_Developer], [cdp_Integration]

