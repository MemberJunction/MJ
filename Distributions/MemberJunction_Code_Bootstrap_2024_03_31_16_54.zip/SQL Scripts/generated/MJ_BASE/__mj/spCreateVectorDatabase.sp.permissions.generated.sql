
GRANT EXECUTE ON [__mj].[spCreateVectorDatabase] TO [cdp_Developer], [cdp_Integration]

