
GRANT EXECUTE ON [__mj].[spUpdateUserFavorite] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

