
GRANT EXECUTE ON [__mj].[spDeleteUserFavorite] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

