
GRANT EXECUTE ON [__mj].[spUpdateEmployeeRole] TO [cdp_Developer], [cdp_Integration]

