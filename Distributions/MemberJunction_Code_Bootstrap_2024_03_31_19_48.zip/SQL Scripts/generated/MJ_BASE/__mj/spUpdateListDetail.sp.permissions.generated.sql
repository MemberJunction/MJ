
GRANT EXECUTE ON [__mj].[spUpdateListDetail] TO [cdp_Developer], [cdp_Integration]

