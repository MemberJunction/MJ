
GRANT EXECUTE ON [__mj].[spCreateWorkspace] TO [cdp_UI]

