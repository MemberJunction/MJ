
GRANT EXECUTE ON [__mj].[spUpdateUserViewRun] TO [cdp_Developer], [cdp_Integration]

