
GRANT EXECUTE ON [__mj].[spUpdateUserViewRunDetail] TO [cdp_Developer], [cdp_Integration]

