
GRANT EXECUTE ON [reference].[spCreateIndustry] TO [cdp_Developer], [cdp_Integration]

