
GRANT EXECUTE ON [__mj].[spUpdateCompanyIntegrationRunDetail] TO [cdp_Developer], [cdp_Integration]

