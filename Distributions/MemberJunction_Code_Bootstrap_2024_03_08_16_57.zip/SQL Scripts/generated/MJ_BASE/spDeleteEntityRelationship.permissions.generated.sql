
GRANT EXECUTE ON [__mj].[spDeleteEntityRelationship] TO [cdp_Developer], [cdp_Integration]

