
GRANT EXECUTE ON [__mj].[spCreateUser] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

