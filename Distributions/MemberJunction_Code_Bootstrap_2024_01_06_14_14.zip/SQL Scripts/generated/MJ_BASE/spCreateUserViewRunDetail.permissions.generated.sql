
GRANT EXECUTE ON [admin].[spCreateUserViewRunDetail] TO [cdp_Developer], [cdp_Integration]

