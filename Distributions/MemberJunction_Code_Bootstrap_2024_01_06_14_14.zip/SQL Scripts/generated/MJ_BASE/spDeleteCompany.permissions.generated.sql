
GRANT EXECUTE ON [admin].[spDeleteCompany] TO [cdp_Developer], [cdp_Integration]

