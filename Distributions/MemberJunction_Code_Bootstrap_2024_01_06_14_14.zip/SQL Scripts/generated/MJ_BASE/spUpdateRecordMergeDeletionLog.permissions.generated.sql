
GRANT EXECUTE ON [admin].[spUpdateRecordMergeDeletionLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]

