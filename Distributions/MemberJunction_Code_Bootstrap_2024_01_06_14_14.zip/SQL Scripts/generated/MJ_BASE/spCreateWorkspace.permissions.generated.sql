
GRANT EXECUTE ON [admin].[spCreateWorkspace] TO [cdp_UI]

