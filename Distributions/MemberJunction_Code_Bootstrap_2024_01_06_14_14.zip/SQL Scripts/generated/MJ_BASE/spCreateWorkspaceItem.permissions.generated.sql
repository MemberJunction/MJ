
GRANT EXECUTE ON [admin].[spCreateWorkspaceItem] TO [cdp_UI]

