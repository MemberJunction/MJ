import { BaseEntity, PrimaryKeyValue } from "@memberjunction/core";
import { RegisterClass } from "@memberjunction/global";
