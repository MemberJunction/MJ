
GRANT EXECUTE ON [admin].[spUpdateWorkflow] TO [cdp_Developer], [cdp_Integration]

