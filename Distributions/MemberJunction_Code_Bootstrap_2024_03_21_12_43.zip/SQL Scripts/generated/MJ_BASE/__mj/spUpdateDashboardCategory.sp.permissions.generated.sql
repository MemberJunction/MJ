
GRANT EXECUTE ON [__mj].[spUpdateDashboardCategory] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

