
GRANT EXECUTE ON [__mj].[spCreateDashboardCategory] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

