
GRANT EXECUTE ON [__mj].[spCreateFile] TO [cdp_Developer], [cdp_Integration]

