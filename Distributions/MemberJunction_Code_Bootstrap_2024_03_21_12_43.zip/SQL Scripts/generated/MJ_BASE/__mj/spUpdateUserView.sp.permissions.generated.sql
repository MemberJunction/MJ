
GRANT EXECUTE ON [__mj].[spUpdateUserView] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

