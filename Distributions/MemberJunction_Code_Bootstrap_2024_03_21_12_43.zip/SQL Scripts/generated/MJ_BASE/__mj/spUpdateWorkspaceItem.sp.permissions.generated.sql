
GRANT EXECUTE ON [__mj].[spUpdateWorkspaceItem] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

