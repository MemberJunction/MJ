
GRANT EXECUTE ON [__mj].[spUpdateRecordMergeLog] TO [cdp_Developer], [cdp_Integration]

