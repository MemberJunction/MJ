
GRANT EXECUTE ON [admin].[spCreateDataContextItem] TO [cdp_Developer], [cdp_Integration]

