
GRANT EXECUTE ON [reference].[spUpdateIndustry] TO [cdp_Developer], [cdp_Integration]

