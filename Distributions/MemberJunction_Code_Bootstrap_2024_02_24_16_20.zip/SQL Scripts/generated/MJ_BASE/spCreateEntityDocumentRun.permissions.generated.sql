
GRANT EXECUTE ON [admin].[spCreateEntityDocumentRun] TO [cdp_Developer], [cdp_Integration]

