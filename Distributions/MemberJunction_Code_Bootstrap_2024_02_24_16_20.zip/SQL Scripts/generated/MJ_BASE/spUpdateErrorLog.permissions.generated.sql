
GRANT EXECUTE ON [admin].[spUpdateErrorLog] TO [cdp_Developer], [cdp_Integration]

