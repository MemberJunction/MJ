
GRANT EXECUTE ON [admin].[spUpdateEntityDocumentRun] TO [cdp_Developer], [cdp_Integration]

