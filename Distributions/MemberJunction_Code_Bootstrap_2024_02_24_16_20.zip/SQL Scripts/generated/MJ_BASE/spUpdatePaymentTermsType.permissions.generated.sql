
GRANT EXECUTE ON [crm].[spUpdatePaymentTermsType] TO [cdp_Developer], [cdp_Integration]

