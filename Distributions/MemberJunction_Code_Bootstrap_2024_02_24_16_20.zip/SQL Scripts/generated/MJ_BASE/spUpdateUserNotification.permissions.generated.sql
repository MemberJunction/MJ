
GRANT EXECUTE ON [admin].[spUpdateUserNotification] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

