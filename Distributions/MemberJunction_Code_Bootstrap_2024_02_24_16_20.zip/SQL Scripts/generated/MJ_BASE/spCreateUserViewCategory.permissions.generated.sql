
GRANT EXECUTE ON [admin].[spCreateUserViewCategory] TO [cdp_Developer], [cdp_Integration]

