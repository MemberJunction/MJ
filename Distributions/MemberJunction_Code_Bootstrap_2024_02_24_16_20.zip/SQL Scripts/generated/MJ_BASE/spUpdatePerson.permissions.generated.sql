
GRANT EXECUTE ON [dbo].[spUpdatePerson] TO [cdp_Developer], [cdp_Integration]

