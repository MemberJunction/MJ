
GRANT EXECUTE ON [admin].[spUpdateRecordMergeLog] TO [cdp_Developer], [cdp_Integration], [cdp_UI], [cdp_Developer], [cdp_Integration]

