
GRANT EXECUTE ON [admin].[spDeleteReportSnapshot] TO [cdp_UI]

