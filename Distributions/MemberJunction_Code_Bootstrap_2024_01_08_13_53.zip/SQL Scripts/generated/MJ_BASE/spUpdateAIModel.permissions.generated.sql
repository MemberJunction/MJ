
GRANT EXECUTE ON [admin].[spUpdateAIModel] TO [cdp_Integration], [cdp_Developer]

