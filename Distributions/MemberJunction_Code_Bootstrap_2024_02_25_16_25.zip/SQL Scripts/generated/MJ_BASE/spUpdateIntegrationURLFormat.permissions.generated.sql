
GRANT EXECUTE ON [admin].[spUpdateIntegrationURLFormat] TO [cdp_Developer], [cdp_Integration]

