
GRANT EXECUTE ON [admin].[spDeleteEmployee] TO [cdp_Developer], [cdp_Integration]

