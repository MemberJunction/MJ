
GRANT EXECUTE ON [admin].[spUpdateEntityPermission] TO [cdp_Developer], [cdp_Integration]

