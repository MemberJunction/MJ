
GRANT EXECUTE ON [admin].[spUpdateVectorDatabase] TO [cdp_Developer], [cdp_Integration]

