
GRANT EXECUTE ON [crm].[spUpdateDeal] TO [cdp_Developer], [cdp_Integration]

