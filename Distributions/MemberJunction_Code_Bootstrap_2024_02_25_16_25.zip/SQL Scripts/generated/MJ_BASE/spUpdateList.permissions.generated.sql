
GRANT EXECUTE ON [admin].[spUpdateList] TO [cdp_Developer], [cdp_Integration]

