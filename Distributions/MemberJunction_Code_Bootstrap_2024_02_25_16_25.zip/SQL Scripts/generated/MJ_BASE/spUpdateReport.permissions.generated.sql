
GRANT EXECUTE ON [admin].[spUpdateReport] TO [cdp_UI]

