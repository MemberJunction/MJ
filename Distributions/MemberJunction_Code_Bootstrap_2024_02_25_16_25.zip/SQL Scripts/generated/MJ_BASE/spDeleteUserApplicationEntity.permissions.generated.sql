
GRANT EXECUTE ON [admin].[spDeleteUserApplicationEntity] TO [cdp_Developer], [cdp_Integration]

