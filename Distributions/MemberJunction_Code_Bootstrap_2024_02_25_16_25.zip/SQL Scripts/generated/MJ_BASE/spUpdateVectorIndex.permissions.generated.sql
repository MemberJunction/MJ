
GRANT EXECUTE ON [admin].[spUpdateVectorIndex] TO [cdp_Developer], [cdp_Integration]

