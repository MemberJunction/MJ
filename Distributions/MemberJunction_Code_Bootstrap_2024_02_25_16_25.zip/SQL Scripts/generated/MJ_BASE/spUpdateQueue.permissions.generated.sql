
GRANT EXECUTE ON [admin].[spUpdateQueue] TO [cdp_Developer], [cdp_Developer]

