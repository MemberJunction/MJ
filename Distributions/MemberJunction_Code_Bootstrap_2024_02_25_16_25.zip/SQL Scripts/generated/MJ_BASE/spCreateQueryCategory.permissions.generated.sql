
GRANT EXECUTE ON [admin].[spCreateQueryCategory] TO [cdp_Developer], [cdp_Integration]

