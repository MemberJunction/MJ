
GRANT EXECUTE ON [admin].[spUpdateDataContextItem] TO [cdp_Developer], [cdp_Integration]

