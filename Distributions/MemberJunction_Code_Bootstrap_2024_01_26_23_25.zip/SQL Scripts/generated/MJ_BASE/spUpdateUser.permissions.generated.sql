
GRANT EXECUTE ON [admin].[spUpdateUser] TO [cdp_Developer], [cdp_Integration]

