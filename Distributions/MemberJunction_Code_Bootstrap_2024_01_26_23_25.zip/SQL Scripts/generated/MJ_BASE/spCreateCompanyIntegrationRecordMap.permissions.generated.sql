
GRANT EXECUTE ON [admin].[spCreateCompanyIntegrationRecordMap] TO [cdp_Developer], [cdp_Integration]

