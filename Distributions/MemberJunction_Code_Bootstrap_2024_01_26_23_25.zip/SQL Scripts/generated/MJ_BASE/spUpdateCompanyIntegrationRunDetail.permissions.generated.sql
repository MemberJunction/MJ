
GRANT EXECUTE ON [admin].[spUpdateCompanyIntegrationRunDetail] TO [cdp_Developer], [cdp_Integration]

