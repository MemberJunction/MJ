
GRANT EXECUTE ON [__mj].[spDeleteReportSnapshot] TO [cdp_UI]

