
GRANT EXECUTE ON [__mj].[spUpdateUserRecordLog] TO [cdp_Developer], [cdp_Integration]

