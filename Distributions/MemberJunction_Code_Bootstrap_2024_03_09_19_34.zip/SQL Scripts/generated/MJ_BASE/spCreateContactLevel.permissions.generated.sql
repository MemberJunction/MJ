
GRANT EXECUTE ON [reference].[spCreateContactLevel] TO [cdp_Developer], [cdp_Integration]

