
GRANT EXECUTE ON [__mj].[spUpdateQueryCategory] TO [cdp_Developer], [cdp_Integration]

