
GRANT EXECUTE ON [crm].[spUpdateInvoiceStatusType] TO [cdp_Developer], [cdp_Integration]

