
GRANT EXECUTE ON [__mj].[spDeleteConversation] TO [cdp_UI]

