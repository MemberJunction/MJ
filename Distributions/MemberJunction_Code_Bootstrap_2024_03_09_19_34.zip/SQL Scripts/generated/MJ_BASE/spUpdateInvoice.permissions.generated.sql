
GRANT EXECUTE ON [crm].[spUpdateInvoice] TO [cdp_Developer], [cdp_Integration]

