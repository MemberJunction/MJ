
GRANT EXECUTE ON [dbo].[spUpdateDemoKey] TO [cdp_Developer], [cdp_Integration]

