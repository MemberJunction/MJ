
GRANT EXECUTE ON [crm].[spDeleteAccount] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

