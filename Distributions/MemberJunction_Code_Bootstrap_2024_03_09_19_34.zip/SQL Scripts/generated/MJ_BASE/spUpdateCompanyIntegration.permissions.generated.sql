
GRANT EXECUTE ON [__mj].[spUpdateCompanyIntegration] TO [cdp_Developer], [cdp_Integration]

