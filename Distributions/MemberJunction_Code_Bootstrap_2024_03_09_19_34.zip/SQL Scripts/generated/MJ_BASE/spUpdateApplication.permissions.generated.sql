
GRANT EXECUTE ON [__mj].[spUpdateApplication] TO [cdp_Developer], [cdp_Integration]

