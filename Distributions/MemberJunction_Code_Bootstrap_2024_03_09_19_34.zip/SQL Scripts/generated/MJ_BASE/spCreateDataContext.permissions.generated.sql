
GRANT EXECUTE ON [__mj].[spCreateDataContext] TO [cdp_Developer], [cdp_Integration]

