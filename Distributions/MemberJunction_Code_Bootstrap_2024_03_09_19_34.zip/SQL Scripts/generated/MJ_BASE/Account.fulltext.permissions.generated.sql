
GRANT SELECT ON [crm].[fnSearchAccounts] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

