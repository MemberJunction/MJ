
GRANT EXECUTE ON [__mj].[spUpdateAIModel] TO [cdp_Integration], [cdp_Developer]

