
GRANT EXECUTE ON [__mj].[spUpdateQueueTask] TO [cdp_Developer], [cdp_Developer]

