
GRANT EXECUTE ON [__mj].[spUpdateUser] TO [cdp_Developer], [cdp_Integration]

