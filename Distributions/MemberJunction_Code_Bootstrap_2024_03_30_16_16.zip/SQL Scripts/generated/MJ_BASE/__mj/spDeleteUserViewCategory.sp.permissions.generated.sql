
GRANT EXECUTE ON [__mj].[spDeleteUserViewCategory] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

