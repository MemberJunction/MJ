
GRANT EXECUTE ON [__mj].[spUpdateRole] TO [cdp_Developer], [cdp_Integration]

