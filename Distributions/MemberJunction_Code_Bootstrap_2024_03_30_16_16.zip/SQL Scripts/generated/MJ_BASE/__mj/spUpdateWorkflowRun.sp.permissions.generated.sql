
GRANT EXECUTE ON [__mj].[spUpdateWorkflowRun] TO [cdp_Developer], [cdp_Integration]

