
GRANT EXECUTE ON [__mj].[spUpdateEntityDocument] TO [cdp_Developer], [cdp_Integration]

