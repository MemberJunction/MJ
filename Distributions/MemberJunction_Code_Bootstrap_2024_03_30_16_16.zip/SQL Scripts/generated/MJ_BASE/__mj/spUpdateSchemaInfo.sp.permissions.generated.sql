
GRANT EXECUTE ON [__mj].[spUpdateSchemaInfo] TO [cdp_Developer], [cdp_Integration]

