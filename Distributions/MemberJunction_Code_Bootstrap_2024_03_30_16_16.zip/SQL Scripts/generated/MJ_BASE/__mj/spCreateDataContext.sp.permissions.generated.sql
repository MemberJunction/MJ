
GRANT EXECUTE ON [__mj].[spCreateDataContext] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

