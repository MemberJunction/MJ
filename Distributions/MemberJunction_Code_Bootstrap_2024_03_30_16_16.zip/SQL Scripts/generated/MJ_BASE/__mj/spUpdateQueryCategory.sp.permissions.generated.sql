
GRANT EXECUTE ON [__mj].[spUpdateQueryCategory] TO [cdp_UI], [cdp_Developer], [cdp_Integration]

