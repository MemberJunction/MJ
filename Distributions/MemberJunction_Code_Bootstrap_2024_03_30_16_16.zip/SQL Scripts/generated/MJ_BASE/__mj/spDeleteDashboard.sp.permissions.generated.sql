
GRANT EXECUTE ON [__mj].[spDeleteDashboard] TO [cdp_UI]

