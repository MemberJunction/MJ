
GRANT EXECUTE ON [__mj].[spUpdateAIModelType] TO [cdp_Integration], [cdp_Developer]

