
GRANT EXECUTE ON [admin].[spUpdateUserViewRunDetail] TO [cdp_Developer], [cdp_Integration]

