
GRANT EXECUTE ON [admin].[spUpdateWorkspace] TO [cdp_UI]

