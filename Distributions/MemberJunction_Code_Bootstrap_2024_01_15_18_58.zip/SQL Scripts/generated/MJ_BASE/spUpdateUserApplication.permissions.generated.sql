
GRANT EXECUTE ON [admin].[spUpdateUserApplication] TO [cdp_Developer], [cdp_Integration]

