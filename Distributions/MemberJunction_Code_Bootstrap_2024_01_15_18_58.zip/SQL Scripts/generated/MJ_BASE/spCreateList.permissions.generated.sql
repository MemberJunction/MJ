
GRANT EXECUTE ON [admin].[spCreateList] TO [cdp_Developer], [cdp_Integration]

