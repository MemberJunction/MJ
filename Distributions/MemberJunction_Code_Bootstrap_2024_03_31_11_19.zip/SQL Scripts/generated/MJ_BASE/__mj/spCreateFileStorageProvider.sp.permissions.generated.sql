
GRANT EXECUTE ON [__mj].[spCreateFileStorageProvider] TO [cdp_Developer], [cdp_Integration]

