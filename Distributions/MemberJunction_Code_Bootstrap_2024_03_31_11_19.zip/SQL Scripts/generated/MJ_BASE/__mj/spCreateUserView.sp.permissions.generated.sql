
GRANT EXECUTE ON [__mj].[spCreateUserView] TO [cdp_Developer], [cdp_Integration], [cdp_UI]

