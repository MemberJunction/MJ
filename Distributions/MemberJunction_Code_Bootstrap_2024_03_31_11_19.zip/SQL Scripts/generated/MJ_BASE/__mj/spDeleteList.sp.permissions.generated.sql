
GRANT EXECUTE ON [__mj].[spDeleteList] TO [cdp_Developer], [cdp_Integration]

