
GRANT EXECUTE ON [__mj].[spCreateEntity] TO [cdp_Developer], [cdp_Integration]

