
GRANT EXECUTE ON [__mj].[spCreateUserRole] TO [cdp_Developer], [cdp_Integration]

