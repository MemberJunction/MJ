
GRANT EXECUTE ON [__mj].[spUpdateReportSnapshot] TO [cdp_UI]

