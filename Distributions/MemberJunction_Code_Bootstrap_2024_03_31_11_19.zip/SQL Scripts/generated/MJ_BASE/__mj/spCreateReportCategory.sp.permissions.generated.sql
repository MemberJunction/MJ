
GRANT EXECUTE ON [__mj].[spCreateReportCategory] TO [cdp_Developer], [cdp_Integration]

