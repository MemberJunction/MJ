
GRANT EXECUTE ON [admin].[spUpdateUserRecordLog] TO [cdp_Developer], [cdp_Integration]

