
GRANT EXECUTE ON [admin].[spUpdateConversationDetail] TO [cdp_UI]

