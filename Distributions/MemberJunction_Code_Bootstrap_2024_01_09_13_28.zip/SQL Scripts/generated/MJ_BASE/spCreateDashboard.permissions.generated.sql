
GRANT EXECUTE ON [admin].[spCreateDashboard] TO [cdp_UI]

