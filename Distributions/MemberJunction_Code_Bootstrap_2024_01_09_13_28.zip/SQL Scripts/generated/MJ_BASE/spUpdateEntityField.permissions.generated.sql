
GRANT EXECUTE ON [admin].[spUpdateEntityField] TO [cdp_Developer], [cdp_Integration]

