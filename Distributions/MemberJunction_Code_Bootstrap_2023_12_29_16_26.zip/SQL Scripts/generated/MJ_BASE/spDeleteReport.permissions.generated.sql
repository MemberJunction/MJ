
GRANT EXECUTE ON [admin].[spDeleteReport] TO [cdp_UI]

