
GRANT EXECUTE ON [admin].[spCreateListDetail] TO [cdp_Developer], [cdp_Integration]

