
GRANT EXECUTE ON [admin].[spUpdateReportSnapshot] TO [cdp_UI]

