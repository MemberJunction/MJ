
GRANT EXECUTE ON [admin].[spUpdateEntityRelationship] TO [cdp_Developer], [cdp_Integration]

