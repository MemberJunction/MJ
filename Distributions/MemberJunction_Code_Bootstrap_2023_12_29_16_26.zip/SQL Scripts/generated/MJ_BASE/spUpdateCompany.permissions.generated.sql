
GRANT EXECUTE ON [admin].[spUpdateCompany] TO [cdp_Developer], [cdp_Integration]

