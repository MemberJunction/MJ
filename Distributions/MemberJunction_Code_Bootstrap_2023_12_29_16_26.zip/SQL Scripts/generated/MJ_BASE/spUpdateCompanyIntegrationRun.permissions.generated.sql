
GRANT EXECUTE ON [admin].[spUpdateCompanyIntegrationRun] TO [cdp_Developer], [cdp_Integration]

