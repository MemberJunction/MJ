
GRANT EXECUTE ON [admin].[spCreateEntityField] TO [cdp_Developer], [cdp_Integration]

