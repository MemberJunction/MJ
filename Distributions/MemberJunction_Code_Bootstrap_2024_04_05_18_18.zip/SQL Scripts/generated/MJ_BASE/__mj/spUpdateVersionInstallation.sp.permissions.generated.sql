
GRANT EXECUTE ON [__mj].[spUpdateVersionInstallation] TO [cdp_Developer], [cdp_Integration]

