
GRANT EXECUTE ON [__mj].[spUpdateFileEntityRecordLink] TO [cdp_Developer], [cdp_Integration]

