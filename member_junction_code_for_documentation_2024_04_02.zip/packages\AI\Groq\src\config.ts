import dotenv from 'dotenv';
dotenv.config();

export const mistralAPIKey: string = process.env.MISTRAL_API_KEY;