# @memberjunction/ng-ask-skip

The `@memberjunction/ng-ask-skip` library is an Angular library with components for including the Ask Skip AI UI into your application.

To use this functionality make sure your index.html in your Angular application includes a reference to Font Awesome which we use within this library:

For example:
`<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">`