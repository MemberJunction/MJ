/*
 * Public API Surface of ng-compare-records
 */

export * from './lib/ng-compare-records.component';
export * from './lib/ng-compare-records.module';
