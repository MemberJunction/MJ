# @memberjunction/ai-gemini
Simple wrapper class for Google Gemini AI Models to use with the MemberJunction framework.