/*
 * Public API Surface of ng-link-directives
 */

export * from './lib/ng-container-directives.module';
export * from './lib/ng-fill-container-directive';
export * from './lib/ng-container-directive'; 
