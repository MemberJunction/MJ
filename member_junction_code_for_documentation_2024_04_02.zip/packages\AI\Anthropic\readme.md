# @memberjunction/ai-anthropic
Simple wrapper class for Anthropic's AI Models to use with the MemberJunction framework.