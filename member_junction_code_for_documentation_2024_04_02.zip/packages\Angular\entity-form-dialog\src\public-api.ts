/*
 * Public API Surface
 */

export * from './lib/module';
export * from './lib/entity-form-dialog/entity-form-dialog.component'
