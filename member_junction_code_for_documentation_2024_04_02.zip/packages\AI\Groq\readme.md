# @memberjunction/ai-gemini
Simple wrapper class for Mistral AI's AI Models to use with the MemberJunction framework.