import { BaseModel } from "./baseModel";


export abstract class BaseDiffusion extends BaseModel {
}
