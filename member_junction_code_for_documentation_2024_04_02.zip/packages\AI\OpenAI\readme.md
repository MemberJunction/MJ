# @memberjunction/ai-gemini
Simple wrapper class for OpenAI's AI Models to use with the MemberJunction framework.